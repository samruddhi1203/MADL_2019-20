package edu.ritindia.a10yearschallenge;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

public class ImageLabAssistant extends AppCompatActivity {
    ImageView imageView;
    ImageButton btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_lab_assistant);
        imageView = findViewById(R.id.iv_assistant);
        btn = findViewById(R.id.btn_click_lab);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(v.getId() == R.id.btn_click_lab) {
                    imageView.setImageResource(R.drawable.la1);
                }
            }
        });
    }
}
