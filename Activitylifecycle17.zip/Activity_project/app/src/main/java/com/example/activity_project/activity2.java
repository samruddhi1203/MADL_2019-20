package com.example.activity_project;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

public class activity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity2);
    }
    protected void onStart()
    {
        super.onStart();
        Log.i("onDestroy","Activity is destroyed.");
    }
    protected void onResume()
    {
        super.onResume();
        Log.i("onDestroy","Activity is destroyed.");
    }
    protected void onPause()
    {
        super.onPause();
        Log.i("onDestroy","Activity is destroyed.");
    }
    protected void onStop()
    {
        super.onStop();
        Log.i("onDestroy","Activity is destroyed.");
    }
    protected void onDestroy()
    {
        super.onDestroy();
        Log.i("onDestroy","Activity is destroyed.");
    }
}
