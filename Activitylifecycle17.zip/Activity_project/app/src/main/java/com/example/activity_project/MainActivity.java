package com.example.activity_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button b;
        b=findViewById(R.id.button);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent I=new Intent(MainActivity.this,activity2.class);
                startActivity(I);
            }
        });


    }
    protected void onstart()
    {
        super.onStart();
        Log.i("onstart()","Activity is restarted.");
    }
    protected void onResume()
    {
        super.onResume();
        Log.i("onResume","Activity is resumed.");
    }
    protected void onPause()
    {
        super.onPause();
        Log.i("onPause","Activity is paused.");
    }
    protected void onStop()
    {
        super.onStop();
        Log.i("onStop","Activity is stopped.");
    }
    protected void onDestroy()
    {
        super.onDestroy();
        Log.i("onDestroy","Activity is destroyed.");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuinflate=getMenuInflater();
        menuinflate();
        getMenuInflater().inflate(R.menu.ritmenu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch(item.getItemId())
        {
            case R.id.item1:
                Toast.makeText(getApplicationContext(),"File is selected",Toast.LENGTH_LONG).show();
                return true;

            case R.id.item2:
                Toast.makeText(getApplicationContext(),"File is saved",Toast.LENGTH_LONG).show();
                return true;

            case R.id.item3:
                Toast.makeText(getApplicationContext(),"File is opened",Toast.LENGTH_LONG).show();
                return true;

            case R.id.item4:
                System.exit(R.id.item4);
               // Toast.makeText(getApplicationContext(),"File is opened",Toast.LENGTH_LONG).show();
                return true;
        }
        return false;
    }

    private void menuinflate() {
    }
}
