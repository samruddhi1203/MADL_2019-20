package edu.rit.gayatri.challenge;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class login extends AppCompatActivity {

    Button btn2;
    EditText txt1,txt2;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        btn2=findViewById(R.id.btn2);
        txt1=findViewById(R.id.txt1);
        txt2=findViewById(R.id.txt2);

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(txt1.getText().toString().equals("Vaibhav"))
                {
                    if(txt2.getText().toString().equals("vai"))
                    {
                        Intent i=new Intent(login.this,image1.class);
                        startActivity(i);
                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(),"Wrong Password",Toast.LENGTH_SHORT).show();
                    }
                }
                else
                {
                    Toast.makeText(getApplicationContext(),"Wrong Username",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
