package com.example.myfirst;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button b;
    EditText e1,e2;
    int num1,num2 ;
    float result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        e1=findViewById(R.id.fn);
        e2=findViewById(R.id.sn);


       b= findViewById(R.id.button1);

       b.setOnClickListener(new View.OnClickListener() {


           @Override
           public void onClick(View v) {
               num1= Integer.parseInt(e1.getText().toString());
               num2= Integer.parseInt(e2.getText().toString());
                float height=(float)num1/100;
               result=(float)(num2)/(height*height);
               Toast.makeText(getApplicationContext(),"BMI "+result+"",Toast.LENGTH_SHORT
               ).show();
           }
       });





    }
}
