package com.example.quiz;

import
        androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.example.quiz.R;
import com.example.quiz.question2;

public class MainActivity extends AppCompatActivity {
RadioGroup RG1;
RadioButton RB1;
Button b1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
RG1=(RadioGroup)findViewById(R.id.radioGroup);
RB1=(RadioButton)findViewById(R.id.r1);
b1=(Button)findViewById(R.id.next);
b1.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) { int id = RG1.getCheckedRadioButtonId();
        Intent intent = new Intent(MainActivity.this, question2.class);
        RB1 = findViewById(id);
        if (RB1.getText().toString().equals("Dennis Ritchie"))
        {
            intent.putExtra("mark1",1);
        }
        else
        {
            intent.putExtra("mark1",0);
        }
        Toast.makeText(getApplicationContext(), RB1.getText().toString(), Toast.LENGTH_SHORT).show();
        startActivity(intent);
    }
});



    }



    }

