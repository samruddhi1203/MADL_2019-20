package com.example.quiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

public class question1 extends AppCompatActivity {

    RadioGroup radioGroup3;
    RadioButton rb3;
    FloatingActionButton fltbtn;
    int num1,num2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question1);
        radioGroup3 = findViewById(R.id.rG);
        fltbtn = findViewById(R.id.floatingActionButton);
        Intent i2=getIntent();
        num1=i2.getIntExtra("mark2",0);
        Toast.makeText(getApplicationContext(), String.valueOf(num1), Toast.LENGTH_SHORT).show();

        fltbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int id1 = radioGroup3.getCheckedRadioButtonId();
                rb3 = findViewById(id1);
                Toast.makeText(getApplicationContext(),rb3.getText().toString(), Toast.LENGTH_SHORT).show();
                if (rb3.getText().toString().equals("Uniform Resource Locator")) {
                    if (num1 == 0) {
                        num2 = num1 + 1;
                    } else if (num1 == 1) {
                        num2 = num1 + 1;
                    } else if (num1 == 2) {
                        num2 = num1 + 1;
                    }
                }
                else
                {
                    num2= num1;
                }

                Snackbar.make(v,"Your Result is "+num2,Snackbar.LENGTH_LONG).setAction("Action",null).show();
            }
        });


    }
}
