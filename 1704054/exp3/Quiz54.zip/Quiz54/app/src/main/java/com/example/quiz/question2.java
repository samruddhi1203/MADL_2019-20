package com.example.quiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class question2 extends AppCompatActivity {
    RadioGroup radioGroup2;
    RadioButton rb2    ;
    Button btn2;
    int num;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question2);
        btn2 = findViewById(R.id.next2);
        radioGroup2 = findViewById(R.id.radioGroup2);
        Intent i=getIntent();
        num=i.getIntExtra("mark1",0);
        Toast.makeText(getApplicationContext(), String.valueOf(num), Toast.LENGTH_SHORT).show();
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("Clicked","Button clicked");
                Toast.makeText(getApplicationContext(),"Entered", Toast.LENGTH_SHORT).show();
                int id1 = radioGroup2.getCheckedRadioButtonId();
                Intent intent = new Intent(question2.this,question1.class);
                rb2 = findViewById(id1);
                if (num == 1)
                {
                    if (rb2.getText().toString().equals("World Wide Web"))
                    {
                        Toast.makeText(getApplicationContext(), rb2.getText().toString(), Toast.LENGTH_SHORT).show();
                        intent.putExtra("mark2",2);

                    }
                    else
                    {
                        intent.putExtra("mark2",num);
                    }
                }
                else if(num == 0)
                {
                    if (rb2.getText().toString().equals("World Wide Web"))
                    {
                        Toast.makeText(getApplicationContext(), rb2.getText().toString(), Toast.LENGTH_SHORT).show();
                        intent.putExtra("mark2",1);

                    }
                }
                else
                {
                    intent.putExtra("mark2",0);
                }

                startActivity(intent);
                Toast.makeText(getApplicationContext(), rb2.getText().toString(), Toast.LENGTH_SHORT).show();


            }

        });
    }
}
