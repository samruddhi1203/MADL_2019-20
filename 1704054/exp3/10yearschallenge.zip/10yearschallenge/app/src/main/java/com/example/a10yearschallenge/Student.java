package com.example.a10yearschallenge;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

public class Student extends AppCompatActivity {
    ImageButton imageButton;
    ImageView img;
    int change=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student);
        img=(ImageView)findViewById(R.id.st1);
        imageButton=(ImageButton)findViewById(R.id.imgbtn);
      //  while(true) {
            imageButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (change == 0) {
                        img.setImageResource(R.drawable.st1);
                        change = 1;
                    }
                    if (change == 1) {
                        img.setImageResource(R.drawable.st2);
                        change = 0;
                    }

                }
            });

    }
}
