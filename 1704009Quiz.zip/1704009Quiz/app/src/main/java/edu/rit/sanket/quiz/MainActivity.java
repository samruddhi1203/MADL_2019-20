package edu.rit.sanket.quiz;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void onClick(View v)
    {
        switch (v.getId()) {
            case R.id.radioButton1:
                if (radioButton1.getText() == radioButton1) {
                    Toast.makeText(MainActivity.this, "You Are Correct", Toast.LENGTH_SHORT).show();
                    NextQuestion(random.nextInt(questionLength));
                } else {
                    over();
                }

                break;
            case R.id.radioButton2:
                if (btn_two.getText() == radioButton1) {
                    Toast.makeText(MainActivity.this, "You Are Correct", Toast.LENGTH_SHORT).show();
                    NextQuestion(random.nextInt(questionLength));
                } else {
                    Over();
                }

                break;

            case R.id.radioButton3:
                if (btn_three.getText() == radioButton1) {
                    Toast.makeText(MainActivity.this, "You Are Correct", Toast.LENGTH_SHORT).show();
                    NextQuestion(random.nextInt(questionLength));
                } else {
                    Over();
                }

                break;

            case R.id.radioButton4:
                if (btn_four.getText() == radioButton1) {
                    Toast.makeText(MainActivity.this, "You Are Correct", Toast.LENGTH_SHORT).show();
                    NextQuestion(random.nextInt(questionLength));
                } else {
                    Over();
                }

                break;


        }