package com.ritshivam.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button b1,b2,b3,b4;
    EditText t1,t2;
    int num1,num2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Toast.makeText(getApplicationContext(),"This is message for you",Toast.LENGTH_LONG).show();
        b1 = findViewById(R.id.button1);
        b2 = findViewById(R.id.button2);
        b3 = findViewById(R.id.button3);
        b4 = findViewById(R.id.button4);
        t1 = findViewById(R.id.editText1);
        t2 = findViewById(R.id.editText2);



        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                num1=Integer.parseInt(t1.getText().toString());
                num2=Integer.parseInt(t2.getText().toString());

                int res = (num1+num2);
                Toast.makeText(getApplicationContext(),"addition is:"+res,Toast.LENGTH_LONG).show();
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                num1=Integer.parseInt(t1.getText().toString());

                num2=Integer.parseInt(t2.getText().toString());
                int res = (num1-num2);
                Toast.makeText(getApplicationContext(),"subtraction is:"+res,Toast.LENGTH_LONG).show();
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                num1=Integer.parseInt(t1.getText().toString());

                num2=Integer.parseInt(t2.getText().toString());
                int res = (num1*num2);
                Toast.makeText(getApplicationContext(),"multiplication is:"+res,Toast.LENGTH_LONG).show();
            }
        });
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                num1=Integer.parseInt(t1.getText().toString());

                num2=Integer.parseInt(t2.getText().toString());
                float res =(float)num1/num2;
                Toast.makeText(getApplicationContext(),"division is:"+res,Toast.LENGTH_LONG).show();
            }
        });
    }
}
