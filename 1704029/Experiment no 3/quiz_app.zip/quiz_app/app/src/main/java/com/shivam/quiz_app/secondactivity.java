package com.shivam.quiz_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class secondactivity extends AppCompatActivity {

    TextView t1;
    RadioGroup rg1;
    RadioButton rb1;
    Button b1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secondactivity);
        b1 = findViewById(R.id.button2);
        rg1 = findViewById(R.id.group2);
        t1 = findViewById(R.id.t1);



        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle b1 =  getIntent().getExtras();
                if(b1==null)
                {
                    return;
                }
                int mess = b1.getInt("message");
               rb1 = findViewById(rg1.getCheckedRadioButtonId());

                Intent i = new Intent(secondactivity.this,thirdactivity.class);
                if(rb1.getText().toString().equals("mumbai")){
                    mess++;
                }
                i.putExtra("message",mess);
                startActivity(i);
            }
        });







    }
}
