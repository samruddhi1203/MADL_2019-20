package com.shivam.quiz_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class MainActivity extends AppCompatActivity {

    Button b1;
    RadioButton r1;
    RadioGroup rb1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b1 = findViewById(R.id.button);
        rb1 = findViewById(R.id.group1);


        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                r1 = findViewById(rb1.getCheckedRadioButtonId());
                final String str = r1.getText().toString();
                int count = 0;
                if(str.equals("delhi")){
                    count=1;
                }
                Intent i = new Intent(MainActivity.this,secondactivity.class);
                i.putExtra("message",count);
                startActivity(i);
            }
        });
    }
}
