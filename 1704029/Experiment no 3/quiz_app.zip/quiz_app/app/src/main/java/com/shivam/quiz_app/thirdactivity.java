package com.shivam.quiz_app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class thirdactivity extends AppCompatActivity {

    TextView t1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thirdactivity);

        t1 = findViewById(R.id.textView);
        Bundle b1 = getIntent().getExtras();
        if(b1==null){
            return;
        }
        int str =  b1.getInt("message");
        t1.setText(str+"");

    }
}
