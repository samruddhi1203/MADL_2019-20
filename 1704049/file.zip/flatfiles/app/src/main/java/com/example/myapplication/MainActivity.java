package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class MainActivity extends AppCompatActivity {
    EditText ed1;
    String name="";
    File f;
    Button r1,w1,r2,w2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ed1 = findViewById(R.id.editText);
        r1 = findViewById(R.id.button2);
        w1 = findViewById(R.id.button);
        w2=findViewById(R.id.button3);
        r2 = findViewById(R.id.button4);
        w1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                name=ed1.getText().toString();
                try
                {
                    OutputStreamWriter osw=new OutputStreamWriter(openFileOutput("student.txt",MODE_PRIVATE));
                    osw.write(name);
                    osw.close();
                    Toast.makeText(getApplicationContext(),"name saved in file!!",Toast.LENGTH_LONG).show();

                    // Toast.makeText(getApplicationContext(), + " saved",
                    //        Toast.LENGTH_LONG).show();
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }

            }
        });

        r1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try
                {
                    InputStreamReader isr=new InputStreamReader(openFileInput("student.txt"));
                    BufferedReader br=new BufferedReader(isr);
                    name=br.readLine();
                    ed1.setText(name);
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }
                Toast.makeText(getApplicationContext(),"name saved in file: "+ ed1.getText(),Toast.LENGTH_LONG).show();

            }
        });

        w2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                File ex= Environment.getExternalStorageDirectory();
                String path=ex.getAbsolutePath()+"/"+"student.txt";
                //Toast.makeText(getApplicationContext(),path+"",Toast.LENGTH_LONG).show();
                try
                {
                    //f=new File(path);
                    FileInputStream f_in=new FileInputStream(path);
                    InputStreamReader isr=new InputStreamReader(f_in);
                    BufferedReader br=new BufferedReader(isr);
                    name=br.readLine();
                    ed1.setText(name);
                    br.close();
                    Toast.makeText(getApplicationContext(),"read",Toast.LENGTH_LONG).show();

                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }

            }
        });

        r2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name=ed1.getText().toString();
                File ex=Environment.getExternalStorageDirectory();
                String path=ex.getAbsolutePath()+"/"+"student.txt";
                try
                {

                    FileOutputStream f_out=new FileOutputStream(path);
                    OutputStreamWriter osw=new OutputStreamWriter(f_out);
                    osw.append(name);
                    osw.close();
                    f_out.close();
                    Toast.makeText(getApplicationContext(),"hii",Toast.LENGTH_LONG).show();

                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }

            }
        });

    }


}
