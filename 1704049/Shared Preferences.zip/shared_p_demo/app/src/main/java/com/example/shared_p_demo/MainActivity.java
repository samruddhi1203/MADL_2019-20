package com.example.shared_p_demo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText e1,e2;
    Button b1,b2,b3;
    SharedPreferences sp;
    SharedPreferences.Editor ed;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        e1=findViewById(R.id.ed1);
        e2=findViewById(R.id.ed2);
        b1=findViewById(R.id.bt1);
        b2=findViewById(R.id.bt2);
        b3=findViewById(R.id.bt3);

        sp=getSharedPreferences("Rit",MODE_PRIVATE);
        ed=sp.edit();

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String s1=e1.getText().toString();
                String s2=e2.getText().toString();
                ed.putString("user",s1);
                ed.putString("Pass",s2);
                ed.commit();
                Toast.makeText(getApplicationContext(),"Saved",Toast.LENGTH_LONG).show();
            }
        });


        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s11=null,s12=null;
                if(sp.contains("user"))
                {
                    s11=sp.getString("user",null);
                }
                if(sp.contains("Pass"))
                {
                    s12=sp.getString("Pass",null);
                }
                e1.setText(s11);
                e2.setText(s12);
                Toast.makeText(getApplicationContext(),"Record Display",Toast.LENGTH_LONG).show();
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                e1.setText("");
                e2.setText("");

            }
        });
        String m1=null,m2=null;
        if(sp.contains("user"))
        {
            m1=sp.getString("user",null);

        }
        if(sp.contains("Pass"))
        {
            m2=sp.getString("Pass",null);
        }
        e1.setText(m1);
        e2.setText(m2);
    }
}
