package com.example.service;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button b1,b2,b3;

    MediaPlayer mediaPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b1=findViewById(R.id.btn1);
        b2=findViewById(R.id.btn2);
        b3=findViewById(R.id.btn3);


        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(mediaPlayer==null)
                {
                    mediaPlayer=MediaPlayer.create(getApplicationContext(),R.raw.dj);
                }
              mediaPlayer.start();
                Toast.makeText(getApplicationContext(),"Music has Started",Toast.LENGTH_LONG).show();
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(mediaPlayer!=null)
                {
                    mediaPlayer.pause();
                }

                Toast.makeText(getApplicationContext(),"Music has Paused",Toast.LENGTH_LONG).show();
            }
        });

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(mediaPlayer!=null)
                {
                    mediaPlayer.release();
                    mediaPlayer=null;
                }
                Toast.makeText(getApplicationContext(),"Music has Stoped",Toast.LENGTH_LONG).show();
            }
        });
    }
}
