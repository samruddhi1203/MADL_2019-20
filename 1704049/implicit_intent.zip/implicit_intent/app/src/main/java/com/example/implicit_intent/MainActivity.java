package com.example.implicit_intent;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button call,dial,contact,browser,camera,gallary,conlog;
    EditText e1;
    int pic_id=123;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        e1=findViewById(R.id.ed1);

        call=findViewById(R.id.b_call);
        dial=findViewById(R.id.b_dial);
        contact=findViewById(R.id.b_contact);
        browser=findViewById(R.id.b_Browser);
        camera=findViewById(R.id.b_camera);
        gallary=findViewById(R.id.b_Gallary);
        conlog=findViewById(R.id.b_log);

        dial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri u = Uri.parse("tel:" + e1.getText().toString());

                // Create the intent and set the data for the
                // intent as the phone number.
                Intent i = new Intent(Intent.ACTION_DIAL, u);

                try {
                    // Launch the Phone app's dialer with a phone
                    // number to dial a call.
                    startActivity(i);
                } catch (SecurityException s) {
                    // show() method display the toast with
                    // exception message.
                    Toast.makeText(getApplicationContext(), "Exception occured", Toast.LENGTH_LONG).show();
                }

            }
        });

        contact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent();
                i.setAction(android.content.Intent.ACTION_VIEW);
                i.setData(ContactsContract.Contacts.CONTENT_URI);
                startActivity(i);
            }
        });

        camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent=  new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                try {
                    startActivityForResult(intent,pic_id);
                }
                catch (SecurityException s)
                {

                    Toast.makeText(getApplicationContext(),"Exception Ocurred",Toast.LENGTH_LONG).show();
                }

            }
        });


        gallary.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Intent.ACTION_VIEW);
                intent.setType("image/*");
                startActivityForResult(intent,1);
            }
        });

        conlog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent();
                i.setAction(Intent.ACTION_VIEW);
                i.setData(Uri.parse("content://call_log/calls"));
                startActivity(i);
            }
        });

        browser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url="http://www.google.com";
                Uri uri=Uri.parse(url);
                Intent intent=new Intent(Intent.ACTION_VIEW,uri);

                if(intent.resolveActivity(getPackageManager())!=null)
                {
                    try {
                        startActivity(intent);
                    }catch (SecurityException s)
                    {
                        Toast.makeText(getApplicationContext(),"Exception Ocurred",Toast.LENGTH_LONG).show();

                    }
                }
            }
        });

    }
}
