package com.example.database_demo_2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class myhelper extends SQLiteOpenHelper {


    public myhelper(Context context)
    {
        super(context,"maa.db",null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db)
    {
        db.execSQL("create table company(id int,name varchar(20))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        db.execSQL("drop table if exists company");
        onCreate(db);
    }

    public void insert_record(int id,String name)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put("ID",id);
        values.put("Name",name);
        db.insert("company",null,values);

    }

    public Cursor get_record()
    {
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor c=db.rawQuery("select * from company",null);
        return c;
    }

    public void update_record(int id, String nm)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put("name",nm);
        db.update("company",values,"id=?",new String[]{String.valueOf(id)});
    }

    public void delete_record(int id)
    {
      SQLiteDatabase db=this.getWritableDatabase();
      db.delete("company","id=?",new String[]{String.valueOf(id)});
    }
}
