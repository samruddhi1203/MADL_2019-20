package com.example.database_demo_2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText e1,e2,e3;
    Button b1,b2,b3,b4;

     myhelper mh;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        e1=findViewById(R.id.ed1);
        e2=findViewById(R.id.ed2);
        e3=findViewById(R.id.ed3);

        b1=findViewById(R.id.bt1);
        b2=findViewById(R.id.bt2);
        b3=findViewById(R.id.bt3);//update
        b4=findViewById(R.id.bt4);

        mh=new myhelper(MainActivity.this);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String s=e1.getText().toString();
                int id=Integer.parseInt(s);
                String nm=e2.getText().toString();
                mh.insert_record(id,nm);
                Toast.makeText(getApplicationContext(),"Record Inserted ",Toast.LENGTH_LONG).show();

            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Cursor c1=mh.get_record();
                StringBuilder sb=new StringBuilder();

                while (c1.moveToNext())
                {
                    sb.append(c1.getInt(0)+"And"+c1.getString(1));
                }

                Toast.makeText(getApplicationContext(),sb.toString(),Toast.LENGTH_LONG).show();


            }
        });

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String roll=e3.getText().toString();
                int r= Integer.parseInt(roll);
                String name=e2.getText().toString();
                mh.update_record(r,name);
                Toast.makeText(getApplicationContext(),"Record Updated",Toast.LENGTH_LONG).show();
            }
        });

        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String i=e3.getText().toString();
                int id=Integer.parseInt(i);
                mh.delete_record(id);
                Toast.makeText(getApplicationContext(),"Record Deleted",Toast.LENGTH_LONG).show();
            }
        });

    }
}
