package com.example.myquiz_demo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class Second extends AppCompatActivity {
    Button b1;
    RadioGroup rg1;
    RadioButton r1,r2;
    int num;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        b1=findViewById(R.id.btn2);
        rg1=findViewById(R.id.rg2);
        r1=findViewById(R.id.rb5);
        r2=findViewById(R.id.rb6);

        Intent i=getIntent();
        num=i.getIntExtra("Marks",0);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

               // Toast.makeText(getApplicationContext(),"Total Marks"+num,Toast.LENGTH_LONG).show();
                Intent intent=new Intent(Second.this,Third.class);


                if(num==1)
                {
                    if(r2.getText().toString().equals("struct"))
                    {
                        intent.putExtra("Marks1",2);
                    }
                    else
                    {
                        intent.putExtra("Marks1",num);
                    }
                }
                else
                {

                    if(r2.getText().toString().equals("struct"))
                    {
                        intent.putExtra("Marks1",1);
                    }
                    else
                    {
                        intent.putExtra("Marks1",0);
                    }
                }
                startActivity(intent);
            }
        });
    }
}
