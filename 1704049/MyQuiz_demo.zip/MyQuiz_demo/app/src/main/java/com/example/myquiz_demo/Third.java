package com.example.myquiz_demo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.ButtonBarLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

public class Third extends AppCompatActivity {

    Button b1;
    int num2;
    FloatingActionButton f1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);

        b1=findViewById(R.id.btn3);
        f1=findViewById(R.id.fab);

        Intent i=getIntent();
        num2=i.getIntExtra("Marks1",0);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Toast.makeText(getApplicationContext(),"Total Marks"+num2,Toast.LENGTH_LONG).show();

            }
        });


        f1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Snackbar.make(v,"Hello I am Snackbar",Snackbar.LENGTH_LONG).setAction("Action",null).show();
            }
        });
    }
}
