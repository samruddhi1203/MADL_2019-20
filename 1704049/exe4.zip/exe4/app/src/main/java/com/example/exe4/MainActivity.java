package com.example.exe4;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    TextView t1;
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.example_menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId())
        {

            case R.id.m1:
                Toast.makeText(getApplicationContext(),"Menu1 Selected",Toast.LENGTH_LONG).show();
                return true;
            case R.id.m2:
                Toast.makeText(getApplicationContext(),"Menu2 Selected",Toast.LENGTH_LONG).show();
                return true;
            case R.id.m3:
                Toast.makeText(getApplicationContext(),"Menu3 Selected",Toast.LENGTH_LONG).show();
                return true;
            case R.id.m4:
                Toast.makeText(getApplicationContext(),"Menu4 Selected",Toast.LENGTH_LONG).show();
                return true;
            case R.id.m5:
                Toast.makeText(getApplicationContext(),"Menu5 Selected",Toast.LENGTH_LONG).show();
                return true;
             default:   return super.onOptionsItemSelected(item);
        }

    }

    @Override
    public void onBackPressed()
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setMessage("Are you sure you want to exit:");
        builder.setCancelable(false);
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                MainActivity.super.onBackPressed();
                //finish();
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        AlertDialog alertDialog=builder.create();
        alertDialog.show();

      //  super.onBackPressed();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        t1=findViewById(R.id.tt);
        registerForContextMenu(t1);



    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);

        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.example_menu,menu);

    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId())
        {

            case R.id.m1:
                Toast.makeText(getApplicationContext(),"Menu1 Selected",Toast.LENGTH_LONG).show();
                return true;
            case R.id.m2:
                Toast.makeText(getApplicationContext(),"Menu2 Selected",Toast.LENGTH_LONG).show();
                return true;
            case R.id.m3:
                Toast.makeText(getApplicationContext(),"Menu3 Selected",Toast.LENGTH_LONG).show();
                return true;
            case R.id.m4:
                Toast.makeText(getApplicationContext(),"Menu4 Selected",Toast.LENGTH_LONG).show();
                return true;
            case R.id.m5:
                Toast.makeText(getApplicationContext(),"Menu5 Selected",Toast.LENGTH_LONG).show();
              //  super.onBackPressed();
                return true;
            default:   return super.onOptionsItemSelected(item);
        }
    }


}
