package com.example.activityapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class Second_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_);
    }
    public void back(View view)
    {
        Intent i=new Intent(Second_Activity.this,MainActivity.class);
        startActivity(i);
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.i("onStart()","Activity is started");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.i("onResume()","Activity resumed");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.i("onPause()","Activity Paused");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.i("onStop()","Activity Stopped");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i("onDestroy()","Activity Destroyed");
    }
}
