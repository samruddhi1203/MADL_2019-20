/*package edu.ritindia.akshay.justmath;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button button1, button2, button3, button4;
    EditText editText1, editText2;
    int res;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        editText1 = findViewById(R.id.editText1);
        editText2 = findViewById(R.id.editText2);
        button1 = findViewById(R.id.button1);
        button2 = findViewById(R.id.button2);
        button3 = findViewById(R.id.button3);
        button4 = findViewById(R.id.button4);

        button1.setOnClickListener(this);
        button2.setOnClickListener(this);
        button3.setOnClickListener(this);
        button4.setOnClickListener(this);
        setContentView(R.layout.activity_main);
    }


        public void Onclick (View v){
            int a = Integer.parseInt(editText1.getText().toString());
            int b = Integer.parseInt(editText2.getText().toString());
            if (v == button1) {
                res = a + b;
                Toast.makeText(getApplicationContext(), "add is " + res, Toast.LENGTH_LONG).show();

            }
            if (v == button2) {
                res = a - b;
                Toast.makeText(getApplicationContext(), "sub is " + res, Toast.LENGTH_LONG).show();

            }
            if (v == button3) {
                res = a * b;
                Toast.makeText(getApplicationContext(), "mul is " + res, Toast.LENGTH_LONG).show();
            }
            if (v == button4) {
                res = a / b;
                Toast.makeText(getApplicationContext(), "div is " + res, Toast.LENGTH_LONG).show();

            }

        }
    }*/

package edu.ritindia.akshay.justmath;

import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Button button1,button2,button3,button4;
    EditText editText1,editText2;
    int res;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText1=findViewById(R.id.editText1);
        editText2=findViewById(R.id.editText2);
        button1=findViewById(R.id.button1);
        button2=findViewById(R.id.button2);
        button3=findViewById(R.id.button3);
        button4=findViewById(R.id.button4);

        button1.setOnClickListener(this);
        button2.setOnClickListener(this);
        button3.setOnClickListener(this);
        button4.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        int a=Integer.parseInt(editText1.getText().toString());
        int b=Integer.parseInt(editText2.getText().toString());
        if (v==button1)
        {
            res=a+b;
            Toast.makeText(getApplicationContext(),"addition is "+res,Toast.LENGTH_LONG).show();
        }
        if (v==button2)
        {
            res=a-b;
            Toast.makeText(getApplicationContext(),"sub is "+res,Toast.LENGTH_LONG).show();
        }
        if (v==button3)
        {
            res=a*b;
            Toast.makeText(getApplicationContext(),"multiplication is "+res,Toast.LENGTH_LONG).show();
        }
        if (v==button4)
        {
            res=a/b;
            Toast.makeText(getApplicationContext(),"division is "+res,Toast.LENGTH_LONG).show();
        }
    }


}


