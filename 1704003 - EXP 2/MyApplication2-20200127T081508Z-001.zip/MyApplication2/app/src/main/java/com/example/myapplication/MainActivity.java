package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Button button1,button2,button3,button4;
    EditText editText1,editText2;
    int result;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText1=findViewById(R.id.edittext1);
        editText2=findViewById(R.id.editText2);
        button1=findViewById(R.id.button1);
        button2=findViewById(R.id.button2);
        button3=findViewById(R.id.button3);
        button4=findViewById(R.id.button4);


        button1.setOnClickListener(this);
        button2.setOnClickListener(this);
        button3.setOnClickListener(this);
        button4.setOnClickListener(this);
    }
    public void onClick(View v)
    {
        int b1=Integer.parseInt(editText1.getText().toString());
        int b2=Integer.parseInt(editText1.getText().toString());
        if(v==button1)
        {
            result=b1+b2;
            Toast.makeText(getApplicationContext(),"Addition is "+result,Toast.LENGTH_LONG).show();
        }
        if(v==button2)
        {
            result=b1-b2;
            Toast.makeText(getApplicationContext(),"Substraction is"+result,Toast.LENGTH_LONG).show();
        }
        if(v==button3)
        {
            result=b1*b2;
            Toast.makeText(getApplicationContext(),"Multiplication is"+result,Toast.LENGTH_LONG).show();
        }
        if(v==button4)
        {
            result=b1/b2;
            Toast.makeText(getApplicationContext(),"Division is"+result,Toast.LENGTH_LONG).show();
        }

    }
}
