package com.example.demo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener
{
    Button btnA,btnS,btnM,btnD;
    EditText etN1,etN2,etR;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etN1=findViewById(R.id.etN1);
        etN2=findViewById(R.id.etN2);
        etR=findViewById(R.id.etR);

        btnA=findViewById(R.id.btnA);
        btnS=findViewById(R.id.btnS);
        btnM=findViewById(R.id.btnM);
        btnD=findViewById(R.id.btnD);

        btnA.setOnClickListener(this);
        btnS.setOnClickListener(this);
        btnM.setOnClickListener(this);
        btnD.setOnClickListener(this);
    }

    @Override
    public void onClick(View v)
    {
        double num1=Double.parseDouble(etN1.getText().toString());
        double num2=Double.parseDouble(etN2.getText().toString());
        if(num1==0 && num2==0) {
            Toast.makeText(getApplicationContext(),"Enter numbers first",Toast.LENGTH_SHORT).show();
        }
        else {
            if(v.getId()==R.id.btnA)
            {
                double r=num1+num2;
                etR.setText(String.valueOf(r));
            }
            else if(v.getId()==R.id.btnS)
            {
                double r=num1-num2;
                etR.setText(String.valueOf(r));
            }
            else if(v.getId()==R.id.btnM)
            {
                double r=num1*num2;
                etR.setText(String.valueOf(r));
            }
            else if(v.getId()==R.id.btnD)
            {
                double r=num1/num2;
                etR.setText(String.valueOf(r));
            }
        }

    }
}
