package rit.edu.akshay.menu;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn=findViewById(R.id.button);

        registerForContextMenu(btn);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        getMenuInflater().inflate(R.menu.main_menu,menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id=item.getItemId();
        if(id==R.id.action_edit)
        {
            Toast.makeText(getApplicationContext(),"edit",Toast.LENGTH_LONG).show();
        }
        if(id==R.id.action_view)
        {
            Toast.makeText(getApplicationContext(),"view",Toast.LENGTH_LONG).show();
        }
        if(id==R.id.action_save)
        {
            Toast.makeText(getApplicationContext(),"save",Toast.LENGTH_LONG).show();
        }
        if(id==R.id.action_exit)
        {

            Toast.makeText(getApplicationContext(),"exit",Toast.LENGTH_LONG).show();
            AlertDialog.Builder al=new AlertDialog.Builder(this);
            al.setMessage("are you sure?")
                    .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            finish();
                        }
                    })
                    .setNegativeButton("no", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Toast.makeText(getApplicationContext(),"cancle",Toast.LENGTH_LONG).show();
                        }
                    })
                    .setNeutralButton("later", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Toast.makeText(getApplicationContext(),"later",Toast.LENGTH_LONG).show();
                        }
                    });
              AlertDialog a=al.create();
              a.show();

        }
        return super.onOptionsItemSelected(item);
    }
}
