package com.example.notification_message;

import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;


public class app extends Application {

    public static final String channel_1_ID= "Channel_1";
    public static final String channel_2_ID= "Channel_2";

    @Override
    public void onCreate() {
        super.onCreate();

        createNotificationChannel();
    }

    public void createNotificationChannel()
    {
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O)
        {
            NotificationChannel Channel_1= new NotificationChannel(
                    channel_1_ID,"channel 1",
                    NotificationManager.IMPORTANCE_HIGH
            );
            Channel_1.setDescription("tihs is channel 1");

            NotificationChannel Channel_2= new NotificationChannel(
                    channel_2_ID,"channel 2",
                    NotificationManager.IMPORTANCE_LOW
            );
            Channel_2.setDescription("tihs is channel 2");

            NotificationManager manager= getSystemService(NotificationManager.class);
            manager.createNotificationChannel(Channel_1);
            manager.createNotificationChannel(Channel_2);
        }
    }
}
