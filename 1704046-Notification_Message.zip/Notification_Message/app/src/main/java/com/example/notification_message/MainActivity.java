package com.example.notification_message;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import static com.example.notification_message.app.channel_1_ID;
import static com.example.notification_message.app.channel_2_ID;

public class MainActivity extends AppCompatActivity {

    private NotificationManagerCompat notificationManager;
    private EditText title;
    private EditText emessage;

    Button c1;
    Button c2;

  //  Button click;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        notificationManager=NotificationManagerCompat.from(this);

        title=findViewById(R.id.editText);
        emessage=findViewById(R.id.editText2);
        c1=findViewById(R.id.button);
        c2=findViewById(R.id.button2);

       // click=findViewById(R.id.button);

    }

    public  void sendonChannel1 (View view){

        String title1=title.getText().toString();
        String message1=emessage.getText().toString();


        Notification notification=new NotificationCompat.Builder(this,channel_1_ID)
                .setSmallIcon(R.drawable.ic_one)
                .setContentTitle(title1)
                .setContentText(message1)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .build();

         notificationManager.notify(1,notification);

    }

    public  void sendonChannel2 (View view){

        String title1=title.getText().toString();
        String message1=emessage.getText().toString();


        Notification notification=new NotificationCompat.Builder(this,channel_2_ID)
                .setSmallIcon(R.drawable.messageicon)
                .setContentTitle(title1)
                .setContentText(message1)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();

        notificationManager.notify(2,notification);

    }



}

 /*
        click.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
             String message="this is a notification examople";
                NotificationCompat.Builder builder= new NotificationCompat.Builder(MainActivity.this)
                        .setSmallIcon(R.drawable.messageicon)
                        .setContentTitle("New notification")
                        .setContentText(message)
                        .setAutoCancel(true);
                       // .setPriority(NotificationCompat.PRIORITY_DEFAULT);

                Intent notificationIntent = new Intent(MainActivity.this, NotificationView.class);
                notificationIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                notificationIntent.putExtra("message", message);
                PendingIntent pendingIntent = PendingIntent.getActivity(MainActivity.this, 0, notificationIntent,
                        PendingIntent.FLAG_UPDATE_CURRENT);
                builder.setContentIntent(pendingIntent);

                NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                manager.notify(0, builder.build());
            }
        });


        */