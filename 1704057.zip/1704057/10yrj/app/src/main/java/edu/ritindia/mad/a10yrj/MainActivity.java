package edu.ritindia.mad.a10yrj;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Spinner ch;
    ArrayAdapter chad;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ch = (Spinner) findViewById(R.id.choice);
        String[] array={"Student","Faculty"};
        chad = new ArrayAdapter.createFromResource(this,android.R.layout.simple_spinner_item,array);

    }
}
