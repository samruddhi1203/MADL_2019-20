package edu.ritindia.mad.calcij;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    Button addj,subj,divj,mulj;
    EditText num1j,num2j;

    public void onClick(View v)
{
    String s1=num1j.getText().toString();
    int a=Integer.parseInt(s1);
    String s2=num2j.getText().toString();
    int b=Integer.parseInt(s2);

    if(v.getId()==R.id.add)
    {

        Toast.makeText(getApplicationContext(), "Sum is: "+(a+b), Toast.LENGTH_SHORT).show();
    }
    if(v.getId()==R.id.sub)
    {

        Toast.makeText(getApplicationContext(), "Difference is: "+(a-b), Toast.LENGTH_SHORT).show();
    }
    if(v.getId()==R.id.div)
    {

        Toast.makeText(getApplicationContext(), "Division is: "+(a/b), Toast.LENGTH_SHORT).show();
    }
    if(v.getId()==R.id.mul)
    {

        Toast.makeText(getApplicationContext(), "Product is: "+(a*b), Toast.LENGTH_SHORT).show();
    }
}
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        addj=findViewById(R.id.add);
        subj=findViewById(R.id.sub);
        mulj=findViewById(R.id.mul);
        divj=findViewById(R.id.div);
        num1j=findViewById(R.id.num1);
        num2j=findViewById(R.id.num2);

        addj.setOnClickListener(this);
        subj.setOnClickListener(this);
        mulj.setOnClickListener(this);
        divj.setOnClickListener(this);

            }
}
