package edu.ritindia.mad.bmij;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText w,h;
    Button c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        w=findViewById(R.id.weight);
        h=findViewById(R.id.height);
        c=findViewById(R.id.cal);
        c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int a=Integer.parseInt(w.getText().toString());
                int b=Integer.parseInt(h.getText().toString());
                float bmi=(a*10000)/(b*b);
                //Toast.makeText(getApplicationContext(),"Bmi is: "+bmi,Toast.LENGTH_LONG).show();

                if(bmi<=15)
                {
                    Toast.makeText(getApplicationContext()," Severely underweight "+bmi,Toast.LENGTH_LONG).show();
                }
                else if (bmi>=16 && bmi<18.5)
                {
                    Toast.makeText(getApplicationContext(),"  underweight "+bmi,Toast.LENGTH_LONG).show();
                }
                else if(bmi>=18.5 && bmi<25)
                {
                    Toast.makeText(getApplicationContext()," Normal "+bmi,Toast.LENGTH_LONG).show();
                }
                else
                {
                    Toast.makeText(getApplicationContext()," Overweight "+bmi,Toast.LENGTH_LONG).show();
                }

            }
        });

    }
}
