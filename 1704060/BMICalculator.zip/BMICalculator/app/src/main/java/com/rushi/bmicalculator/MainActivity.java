package com.rushi.bmicalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button bt_cal;
    TextView height,weight,res;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

      bt_cal=findViewById(R.id.button);
      height=findViewById(R.id.height);
      weight=findViewById(R.id.weight);
      res=findViewById(R.id.result);

      bt_cal.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {

              float result;
              float a=Float.parseFloat(height.getText().toString());
              float b=Float.parseFloat(weight.getText().toString());

              result=(b)/(a*a);

              res.setText("BMI is " +result);
          }
      });



    }
}
