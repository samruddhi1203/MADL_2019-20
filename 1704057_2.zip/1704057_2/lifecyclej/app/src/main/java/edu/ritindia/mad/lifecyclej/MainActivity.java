package edu.ritindia.mad.lifecyclej;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn=findViewById(R.id.button);
        registerForContextMenu(btn);
        Log.i("onCreate()","onCreate has been called");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater infl=getMenuInflater();
        infl.inflate(R.menu.omenu,menu);
        Log.i("onCreateOptionsMenu()","Options menu has been created");
            return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
       switch (item.getItemId())
       {
           case R.id.item1:
               Toast.makeText(getApplicationContext(),"login",Toast.LENGTH_SHORT).show();
               break;
           case R.id.item2:
               Toast.makeText(getApplicationContext(),"logout",Toast.LENGTH_SHORT).show();
               break;
       }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inf= getMenuInflater();
        inf.inflate(R.menu.omenu,menu);
        Log.i("onCreateContextMenu()","Context menu has been created");
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId())
        {
            case R.id.item1:
                Toast.makeText(getApplicationContext(),"login",Toast.LENGTH_SHORT).show();
                break;
            case R.id.item2:
                Toast.makeText(getApplicationContext(),"logout",Toast.LENGTH_SHORT).show();
                break;
        }
        return super.onContextItemSelected(item);
    }
}
