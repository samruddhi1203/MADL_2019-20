package edu.rit.haidar.a10yearchallenge;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button btn1, btn2;
    Spinner sp ;
    EditText ed1, ed2 ;
    ArrayAdapter arrayAdapter ;
    Intent intent ;
    String s1;
    String fac_name ="abcd",fac_pass="1234",stu_name="haidar",stu_pass="4010",lab_name="pqrs",lab_pass="7890";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn1 = findViewById(R.id.button1);
        btn2 = findViewById(R.id.button2);
          sp = findViewById(R.id.spinner);
          ed1 = findViewById(R.id.editText1);
          ed2 = findViewById(R.id.editText2);
            String item [] = {"Faculty","Student", "Lab Assistent"} ;
            arrayAdapter = new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,item) ;
            arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            sp.setAdapter(arrayAdapter);
            sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {


                        s1 = ((TextView)view).getText().toString();

                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });

            btn1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (ed1.getText().toString().equals(fac_name) && ed2.getText().toString().equals(fac_pass) && s1.equals("Faculty"))
                    {
                        Intent i = new Intent(getApplicationContext(),Faculty.class);
                        startActivity(i);
                    }
                    if (ed1.getText().toString().equals(stu_name) && ed2.getText().toString().equals(stu_pass) && s1.equals("Student"))
                    {
                        Intent i = new Intent(getApplicationContext(),Student.class);
                        startActivity(i);
                    }
                    if (ed1.getText().toString().equals(lab_name) && ed2.getText().toString().equals(lab_pass) && s1.equals("Lab Assistent"))
                    {
                        Intent i = new Intent(getApplicationContext(),Lab_asis.class);
                        startActivity(i);
                    }


                }
            });






    }
}
