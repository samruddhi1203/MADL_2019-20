package edu.rit.haidar.a10yearchallenge;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class Lab_asis extends AppCompatActivity {

    Button btn;
    ImageView iv ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab_asis);

        btn = findViewById(R.id.button);
        iv = findViewById(R.id.imageView3);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iv.setImageResource(R.drawable.l2);
            }
        });

    }
}
