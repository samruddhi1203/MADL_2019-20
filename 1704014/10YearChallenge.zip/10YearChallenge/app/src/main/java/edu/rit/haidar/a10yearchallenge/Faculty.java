package edu.rit.haidar.a10yearchallenge;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class Faculty extends AppCompatActivity {



    Button btn1 ;
    ImageView iv2 ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_faculty);

        btn1 = findViewById(R.id.button1);
        iv2 = findViewById(R.id.imageView);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iv2.setImageResource(R.drawable.faculty3);
                //Toast.makeText(getApplicationContext(),"hello",Toast.LENGTH_LONG).show();
            }
        });





    }
}
