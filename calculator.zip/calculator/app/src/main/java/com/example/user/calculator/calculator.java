package com.example.user.calculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class calculator extends AppCompatActivity implements View.OnClickListener {
    EditText et1, et2;
    Button b2, b3, b4, b5;
    int a, b;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculator);

        et1 = findViewById(R.id.et1);
        et2 = findViewById(R.id.et2);
        b2 = findViewById(R.id.b2);
        b3 = findViewById(R.id.b3);
        b4 = findViewById(R.id.b4);
        b5 = findViewById(R.id.b5);



        b2.setOnClickListener(this);
        b3.setOnClickListener(this);
        b4.setOnClickListener(this);
        b5.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        a = Integer.parseInt(et1.getText().toString());
        b = Integer.parseInt(et2.getText().toString());

        if (v.getId() == R.id.b2) {
            Toast.makeText(getApplicationContext(), "Addition is " + (a + b), Toast.LENGTH_LONG).show();

        }
        else if(v.getId() == R.id.b3) {
            Toast.makeText(getApplicationContext(), "Substraction is " + (a - b), Toast.LENGTH_LONG).show();

        }
        else if(v.getId() == R.id.b4) {
            Toast.makeText(getApplicationContext(), "Multiplication is " + (a * b), Toast.LENGTH_LONG).show();

        }
        else if(v.getId() == R.id.b5) {
            Toast.makeText(getApplicationContext(), "Division is " + (a / b), Toast.LENGTH_LONG).show();

        }
        else  {
            Toast.makeText(getApplicationContext(), "Choose correct button " , Toast.LENGTH_LONG).show();

        }

    }
}