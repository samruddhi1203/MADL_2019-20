package edu.ritindia.jerryindia.spotify;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.IBinder;

import androidx.annotation.Nullable;

import edu.ritindia.jerryindia.spotify.R;

public class meraapnegaane extends Service
{
    MediaPlayer m1;
    @Nullable
    @Override
    public void onCreate()
    {
        m1=MediaPlayer.create(this,R.raw.see_you_again);
    }
    public int onStartCommand(Intent intent, int flags, int startId)
    {
        m1.start();
        return super.onStartCommand(intent,flags,startId);
    }

    @Override
    public void onDestroy()
    {
        m1.stop();
        super.onDestroy();
    }

    public void onPause()
    {

    }

    public IBinder onBind(Intent intent)
    {
        return null;
    }
}
