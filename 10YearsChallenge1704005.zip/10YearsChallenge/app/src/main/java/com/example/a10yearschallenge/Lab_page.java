package com.example.a10yearschallenge;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

public class Lab_page extends AppCompatActivity {

    ImageView i;
    ImageButton b;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab_page);

        i=findViewById(R.id.imageView3);
        b=findViewById(R.id.imageButton3);

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                i.setImageResource(R.drawable.alab);
                Toast.makeText(getApplicationContext(),"After 10 years",Toast.LENGTH_LONG).show();
            }
        });
    }
}
