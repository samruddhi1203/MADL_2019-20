package com.example.videoplayer;

import androidx.appcompat.app.AppCompatActivity;

import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.MediaController;
import android.widget.VideoView;

public class MainActivity extends AppCompatActivity {

    Button b1;
    VideoView videoView;
    MediaController mediaController;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b1=findViewById(R.id.play);
        videoView=findViewById(R.id.vv);
        mediaController=new MediaController(this);
        mediaController.setAnchorView(videoView);
        final String path="android.resources://"+getPackageName()+"/"+R.raw.myvideo;

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Uri uri= Uri.parse(path);
                videoView.setVideoURI(uri);
                videoView.requestFocus();
                videoView.setMediaController(mediaController);
                videoView.start();
            }
        });
    }
}
