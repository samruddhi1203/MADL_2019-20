package com.example.exp5;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.Toast;
import android.widget.Toolbar;

public class MainActivity extends AppCompatActivity {

    Button closeButton;
    Toolbar toolbar ;
    AlertDialog.Builder builder;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
         toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        showLog("OnCreate Finish...");

        closeButton = (Button) findViewById(R.id.button3);
        builder = new AlertDialog.Builder(this);
        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                builder.setMessage(R.string.dialog_message).setTitle(R.string.dialog_title);
                builder.setMessage("Confirm???").setCancelable(false).setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                        Toast.makeText(getApplicationContext(), "You choose yes action for alert", Toast.LENGTH_SHORT).show();
                    }
                }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {


                        {
                            dialog.cancel();
                            Toast.makeText(getApplicationContext(), "You choose no action for alert", Toast.LENGTH_SHORT).show();
                        }

                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("AlertDialogExample");
                alert.show();

            }
        });
    }

    private void setSupportActionBar(Toolbar toolbar) {
    }

    public boolean onCreateOptionMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main_menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id) {
            case R.id.item1:
                Toast.makeText(getApplicationContext(), "Item 1 Selected", Toast.LENGTH_LONG).show();
                return true;
            case R.id.item2:
                Toast.makeText(getApplicationContext(), "Item 2 Selected", Toast.LENGTH_LONG).show();
                return true;
            case R.id.item3:
                Toast.makeText(getApplicationContext(), "Item 3 Selected", Toast.LENGTH_LONG).show();
                return true;
            case R.id.item4:
                Toast.makeText(getApplicationContext(), "Item 4Selected", Toast.LENGTH_LONG).show();
                return true;
             default:
                 return super.onOptionsItemSelected(item);
        }
    }

    protected  void onStart()
    {
        super.onStart();
        showLog("onStart...");
    }

    protected  void onResume()
    {
        super.onResume();
        showLog("onResume...");
    }
    protected  void onPause()
    {
        super.onPause();
        showLog("onPause...");
    }
    protected  void onStop()
    {
        super.onStop();
        showLog("onStop...");
    }
    protected  void onRestart()
    {
        super.onRestart();
        showLog("onRestart...");
    }
    protected  void onDestroy()
    {
        super.onDestroy();
        showLog("onDestroy...");
    }
    public void start(View view)
    {
        startActivity(new Intent(this,Second.class));
    }
    public void exit(View view)
    {
        finish();
    }
    private  void  showLog(String msg)
    {
        Log.d("Lifecycle Text",msg);
    }
    }
