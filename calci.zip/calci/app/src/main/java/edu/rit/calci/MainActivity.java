package edu.rit.calci;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    TextView t1, t2,t3;
    EditText e1, e2;
    Button b1, b2, b3, b4;
    int  a, b;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        t1 = findViewById(R.id.t1);
        t2 = findViewById(R.id.t2);
        t3 = findViewById(R.id.t3);
        e1 = findViewById(R.id.e1);
        e2 = findViewById(R.id.e2);
        b1 = findViewById(R.id.button);
        b4 = findViewById(R.id.button3);
        b3 = findViewById(R.id.button2);
        b2 = findViewById(R.id.button1);



        b1.setOnClickListener(this);
        b2.setOnClickListener(this);
        b3.setOnClickListener(this);
        b4.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {

        a = Integer.parseInt(e1.getText().toString());
        b = Integer.parseInt(e2.getText().toString());
        if (v.getId() == R.id.button) {
            int res = a + b;
            Toast.makeText(getApplicationContext(), "addition is :" + res, Toast.LENGTH_LONG).show();

        } else if (v.getId() == R.id.button1) {
            int res = a - b;
            Toast.makeText(getApplicationContext(), "substration is :" + res, Toast.LENGTH_LONG).show();

        } else if (v.getId() == R.id.button2) {
            int res = a * b;
            Toast.makeText(getApplicationContext(), "multiplition is :" + res, Toast.LENGTH_LONG).show();

        } else if (v.getId() == R.id.button3) {
            int res = a / b;
            Toast.makeText(getApplicationContext(), "divition is :" + res, Toast.LENGTH_LONG).show();

        } else {
            Toast.makeText(getApplicationContext(), "enter correct option", Toast.LENGTH_SHORT).show();

        }

    }
}