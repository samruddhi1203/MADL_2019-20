package edu.ritindia.i4_1854008.bmi_calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    Button cal;
    EditText w,h;
    TextView res;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        w=findViewById(R.id.editText);
        h=findViewById(R.id.editText2);
        cal=findViewById(R.id.btn_calc);
        res=findViewById(R.id.textView2);

        cal.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(v.getId()==cal.getId())
        {
            float w1,h1,ans;

            w1=Float.parseFloat(w.getText().toString());
            h1=Float.parseFloat((h.getText().toString()));

            ans=(w1)/(h1/100*h1/100);

            if(ans<18.5)
            {
                res.setText(""+ans+"-Below Normal weight");
            }
            else if(ans>=18.5 && ans<25)
            {
                res.setText(""+ans+"-Normal weight");
            }
            else if(ans>=25 && ans<30)
            {
                res.setText(""+ans+"-Over weight");
            }
            else
            {
                res.setText(""+ans+"-Obesity");
            }


        }
    }
}
