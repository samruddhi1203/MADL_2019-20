 package edu.rit.bmicalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

 public class MainActivity extends AppCompatActivity {


    EditText ed1,ed2;
    Button btn_bmi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ed1=findViewById(R.id.edit_hight);
        ed2=findViewById(R.id.edit_weight);
        btn_bmi=findViewById(R.id.btn_cal_bmi);


        btn_bmi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float height=Integer.parseInt(ed1.getText().toString());
                float weight=Integer.parseInt(ed2.getText().toString());

                float height_mtr=height/100;

                float res=(float)weight/(height_mtr*height_mtr);

               // Toast.makeText(getApplicationContext(),"Your BMI is "+res,Toast.LENGTH_LONG).show();

                if(res<18.5)
                {
                    Toast.makeText(getApplicationContext(),"Your BMI is = "+res+" Underweight",Toast.LENGTH_LONG).show();

                }
                else if(res>8.5 && res<24.9)
                {
                    Toast.makeText(getApplicationContext(),"Your BMI is = "+res+" Normal weight",Toast.LENGTH_LONG).show();

                }
                else if(res==25 && res<29.9)
                {
                    Toast.makeText(getApplicationContext(),"Your BMI is = "+res+" Over weight",Toast.LENGTH_LONG).show();

                }
                else if(res>=30)
                {
                    Toast.makeText(getApplicationContext(),"Your BMI is = "+res+" Obesity",Toast.LENGTH_LONG).show();

                }





            }
        });

    }
}
