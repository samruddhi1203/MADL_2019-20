package edu.ritindia.balram.bmi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    Button b1;

    EditText e1,e2,e3;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b1=findViewById(R.id.button);

        e1=findViewById(R.id.editText);
        e2=findViewById(R.id.editText2);
        e3=findViewById(R.id.editText3);



b1.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {

        double d1=Integer.parseInt(e1.getText().toString());

        double d2=Integer.parseInt(e1.getText().toString());

        double result=d1/(d1*d2);




          if(result>=25)
          {
              e3.setText(String.valueOf(result)+" "+" OverWeight");
          }else if(result<25 && result>18)
          {

              e3.setText(String.valueOf(result)+" "+" Healthy");

          }
          else
          {
              e3.setText(String.valueOf(result)+" "+" abnormal");

          }






    }
});


    }
}
