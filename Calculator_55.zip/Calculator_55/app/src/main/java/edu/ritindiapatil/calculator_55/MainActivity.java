package edu.ritindiapatil.calculator_55;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
        Button b1,b2,b3,b4;
        EditText e1,e2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1 =findViewById(R.id.button_mul);
        b2 =   findViewById(R.id.button_add);
        b3 =  findViewById(R.id.button_sub);
        b4 =  findViewById(R.id.button_div);
        e1 =  findViewById(R.id.edittext1);
        e2 =  findViewById(R.id.edittext2);

        b1.setOnClickListener(this);
        b2.setOnClickListener(this);
        b3.setOnClickListener(this);
        b4.setOnClickListener(this);
    }

    public void onClick(View v) {
        int num1=Integer.parseInt(e1.getText().toString());
        int num2=Integer.parseInt(e2.getText().toString());
        if(v.getId()==R.id.button_add){
            int  Result=num1+num2;
            Toast.makeText(getApplicationContext(),"Addition of two  num :"+Result,Toast.LENGTH_LONG).show();

        }
        if(v.getId()==R.id.button_mul){
            int Result=num1*num2;
            Toast.makeText(getApplicationContext(),"Multiplication of two  num :"+Result,Toast.LENGTH_LONG).show();

        }
        if(v.getId()==R.id.button_div){
            int Result=num1/num2;
            Toast.makeText(getApplicationContext(),"Division of two  num :"+Result,Toast.LENGTH_LONG).show();

        }
        if(v.getId()==R.id.button_sub){
            int Result=num1-num2;
            Toast.makeText(getApplicationContext(),"Substraction of two  num :"+Result,Toast.LENGTH_LONG).show();

        }

    }
}
