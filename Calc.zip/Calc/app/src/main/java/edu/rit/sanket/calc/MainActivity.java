package edu.rit.sanket.calc;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    Button b1,b2,b3,b4;
    EditText ed1,ed2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b1=findViewById(R.id.button);
        b2=findViewById(R.id.button2);
        b3=findViewById(R.id.button3);
        b4=findViewById(R.id.button4);
        ed1 = findViewById(R.id.editText);
        ed2 = findViewById(R.id.editText2);
        b1.setOnClickListener(this);
        b2.setOnClickListener(this);
        b3.setOnClickListener(this);
        b4.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {

        String s1 = ed1.getText().toString();
        String s2 = ed2.getText().toString();

        int num1 = Integer.parseInt(s1);
        int num2 = Integer.parseInt(s2);

        if(v.getId()==R.id.button)
        {

            Toast.makeText(getApplicationContext(), "Addition is "+(num1+num2), Toast.LENGTH_SHORT).show();
        }

        if(v.getId()==R.id.button2)
        {

            Toast.makeText(getApplicationContext(), "Subtraction is "+(num1-num2), Toast.LENGTH_SHORT).show();
        }

        if(v.getId()==R.id.button3)
        {

            Toast.makeText(getApplicationContext(), "Multiplication is "+(num1*num2), Toast.LENGTH_SHORT).show();
        }

        if(v.getId()==R.id.button4)
        {   double div =(double) num1/num2;
            try{

                Toast.makeText(getApplicationContext(), "Division is "+div, Toast.LENGTH_SHORT).show();
            }catch(Exception e)
            {

                Toast.makeText(getApplicationContext(), "Division is InFiNiTe", Toast.LENGTH_SHORT).show();
            }


        }

    }
}
