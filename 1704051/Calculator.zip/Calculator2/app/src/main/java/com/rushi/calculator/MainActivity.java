package com.rushi.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    Button bt_add,bt_sub,bt_mult,bt_div;
    TextView num1,num2,result;
    int a,b,res;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bt_add=findViewById(R.id.button_add);
        bt_sub=findViewById(R.id.button_sub);
        bt_mult=findViewById(R.id.button_mult);
        bt_div=findViewById(R.id.button_div);
        num1=findViewById(R.id.num1);
        num2=findViewById(R.id.num2);
        result=findViewById(R.id.result);

        bt_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

             a=Integer.parseInt(num1.getText().toString());
             b=Integer.parseInt(num2.getText().toString());
             res=a+b;

             result.setText("Addition is " +res);
            }
        });

        bt_sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a=Integer.parseInt(num1.getText().toString());
                b=Integer.parseInt(num2.getText().toString());
                res=a-b;
                result.setText("Subtraction is " +res);
            }
        });

        bt_mult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a=Integer.parseInt(num1.getText().toString());
                b=Integer.parseInt(num2.getText().toString());
                res=a*b;
                result.setText("Multiplication is " +res);
            }
        });


        bt_div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a=Integer.parseInt(num1.getText().toString());
                b=Integer.parseInt(num2.getText().toString());
                try{
                    res=a/b;
                    result.setText("Division is " +res);
                }
                catch(Exception e)
                {
                    Toast.makeText(getApplicationContext(),"Division is Infinity",Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
}
