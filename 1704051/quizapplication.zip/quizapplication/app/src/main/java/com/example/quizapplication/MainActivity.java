package com.example.quizapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity implements View.OnClickListener
{
    RadioGroup rg1,rg2,rg3;
   public  int i1,i2,i3,res=0;

    RadioButton r1,r2,r3;
    FloatingActionButton fa1;

    String s1="Operating System",s2="Vint Cerf and Robert Kahn",s3="Resistor";
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rg1=findViewById(R.id.rg1);
        rg2=findViewById(R.id.rg2);
        rg3=findViewById(R.id.rg3);


        fa1=findViewById(R.id.floatingActionButton3);
        fa1.setOnClickListener(this);

    }

    @Override
    public void onClick(View v)
    {
        if(v.getId()==R.id.floatingActionButton3)
        {
            i1=rg1.getCheckedRadioButtonId();
            i2=rg2.getCheckedRadioButtonId();
            i3=rg3.getCheckedRadioButtonId();

            r1=findViewById(i1);
            r2=findViewById(i2);
            r3=findViewById(i3);

            //Toast.makeText(this, s1+"   "+r1.getText(), Toast.LENGTH_SHORT).show();

            if(s1.equals(r1.getText().toString()))
            {
                res++;
            }
            if(s2.equals(r2.getText().toString()))
            {
                res++;
            }
            if(s3.equals(r3.getText().toString()))
            {
                res++;
            }
            Snackbar.make(v,"Score :- "+res,Snackbar.LENGTH_LONG).show();
        }
    }
}
