package com.example.anim_demo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;

import com.tomer.fadingtextview.FadingTextView;

import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {
    private FadingTextView fadingTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fadingTextView=findViewById(R.id.fading_text_view);
    }

    public void startExample(View v){
        String[] example2={"And","this","is","sentence 2"};
        fadingTextView.setTexts(example2);
        fadingTextView.setTimeout(500, TimeUnit.MILLISECONDS);

    }

}
