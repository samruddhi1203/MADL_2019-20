package edu.ritindia.a10yearschallenge;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    String role[] = {"Faculty", "Lab assistant","Student"};
    String faculty_user = "Faculty" ,faculty_pass = "123",stud_user ="Student",stud_pass ="123",lab_user ="Assistant",lab_pass="123";
    Spinner spinner;
    String  selected_role;
    ArrayAdapter arrayAdapter;
    EditText eduser,edpass;
    Button login;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        eduser = findViewById(R.id.editText_username);
        edpass = findViewById(R.id.editText_password);
        login = findViewById(R.id.button_login);
        spinner=findViewById(R.id.spinner_role);
        arrayAdapter = new ArrayAdapter(this,android.R.layout.simple_spinner_item,role);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(arrayAdapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    selected_role = spinner.getSelectedItem().toString();
                }

                if (position == 1) {
                    selected_role = spinner.getSelectedItem().toString();
                }

                if (position == 2) {
                    selected_role = spinner.getSelectedItem().toString();
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(selected_role == "Faculty")
                {
                    if(faculty_user.equals(eduser.getText().toString()) && faculty_pass.equals(edpass.getText().toString()))
                    {
                        Intent i = new Intent(getApplicationContext(),ImageFaculty.class);
                        startActivity(i);
                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(), "Enter valid Username or Password", Toast.LENGTH_SHORT).show();
                    }
                }
                if(selected_role == "Lab assistant")
                {
                    if(lab_user.equals(eduser.getText().toString()) && lab_pass.equals(edpass.getText().toString()))
                    {
                        Intent i = new Intent(getApplicationContext(),ImageLabAssistant.class);
                        startActivity(i);
                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(), "Enter valid Username or Password", Toast.LENGTH_SHORT).show();
                    }
                }
                if(selected_role == "Student")
                {
                    if(stud_user.equals(eduser.getText().toString()) && stud_pass.equals(edpass.getText().toString()))
                    {
                        Intent i = new Intent(getApplicationContext(),ImageChange.class);
                        startActivity(i);
                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(), "Enter valid Username or Password", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}
