package edu.ritindia.jerryindia.actj;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener
{
    MediaPlayer m1;
    Button b1,b2,b3;
    int paused;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=findViewById(R.id.button);
        b2=findViewById(R.id.button2);
        b3=findViewById(R.id.button3);

        b1.setOnClickListener(this);
        b2.setOnClickListener(this);
        b3.setOnClickListener(this);
    }


    @Override
    public void onClick(View view)
    {
        if(view.getId()==R.id.button)
        {
            if(m1==null)
            {
                m1=MediaPlayer.create(this,R.raw.daddyyank);
                m1.start();
            }
            else if(!m1.isPlaying())
            {
                m1.seekTo(paused);
                m1.start();
            }
        }
        else if(view.getId()==R.id.button2)
        {
            if(m1!=null)
            {
                m1.pause();
                paused=m1.getCurrentPosition();
            }
        }
        else if(view.getId()==R.id.button3)
        {
            if(m1!=null)
            {
                m1.stop();
                m1=null;
            }
        }
    }
}
