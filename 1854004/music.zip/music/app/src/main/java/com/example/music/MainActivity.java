package com.example.music;


import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Button start,pause,stop;
    MediaPlayer mp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        start=findViewById(R.id.button1);
        pause=findViewById(R.id.button2);
        stop=findViewById(R.id.button3);
        start.setOnClickListener(this);
        pause.setOnClickListener(this);
        stop.setOnClickListener(this);

        mp= MediaPlayer.create(MainActivity.this,R.raw.song);

    }

    @Override
    public void onClick(View v) {
            if(v.getId()==R.id.button1)
            {
                mp.start();
            }
            if(v.getId()==R.id.button2)
            {
                mp.pause();
            }
            if(v.getId()==R.id.button3)
            {
                mp.stop();
            }
    }
}
