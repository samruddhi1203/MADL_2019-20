package edu.ritindia.mad.quiz;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    RadioButton r1,r2,r3;
    RadioGroup rg11,rg12,rg13;
    int rid1,rid2,rid3;
    String ans1="D - A and B",ans2="D - All of above",ans3="A - A class that can create only one object";
    String a1,a2,a3;
    int res;
    FloatingActionButton floatingActionButton;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        rg11=findViewById(R.id.rg1);
        rg12=findViewById(R.id.rg2);
        rg13=findViewById(R.id.rg3);
        floatingActionButton=findViewById(R.id.floatingActionButton1);
        floatingActionButton.setOnClickListener(this);



    }

    @Override
    public void onClick(View v)
    {
        if(v.getId()==R.id.floatingActionButton1)
        {
            rid1=rg11.getCheckedRadioButtonId();
            rid2=rg12.getCheckedRadioButtonId();
            rid3=rg13.getCheckedRadioButtonId();
            r1=findViewById(rid1);
            r2=findViewById(rid2);
            r3=findViewById(rid3);
            a1=r1.getText().toString();
            a2=r2.getText().toString();
            a3=r3.getText().toString();
            if(a1.equals(ans1))
            {
                res++;
            }
            if(a2.equals(ans2))
            {
                res++;
            }
            if(a3.equals(ans3))
            {
                res++;
            }


            Snackbar.make(v, "score= "+res, Snackbar.LENGTH_LONG).show();

    }



    }
}
