package edu.ritindia.shruti.calc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
{
    Button b1,b2,b3,b4;
    EditText e1,e2,e3;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b1=findViewById(R.id.button1);
        b2=findViewById(R.id.button4);
        b3=findViewById(R.id.button3);
        b4=findViewById(R.id.button2);


        e1=findViewById(R.id.editText);
        e2=findViewById(R.id.editText3);
        e3=findViewById(R.id.editText4);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                int s=Integer.parseInt(e1.getText().toString());

                int s1=Integer.parseInt(e2.getText().toString());

                int sum=s+s1;

                e3.setText(String.valueOf(sum));

            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                int s=Integer.parseInt(e1.getText().toString());

                int s1=Integer.parseInt(e2.getText().toString());

                int sum=s-s1;

                e3.setText(String.valueOf(sum));

            }
        });

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                int s=Integer.parseInt(e1.getText().toString());

                int s1=Integer.parseInt(e2.getText().toString());

                int sum=s*s1;

                e3.setText(String.valueOf(sum));

            }
        });

        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                int s=Integer.parseInt(e1.getText().toString());

                int s1=Integer.parseInt(e2.getText().toString());
            try
            {
                float sum=s/s1;
                e3.setText(String.valueOf(sum));
            }catch(Exception e)
                {
                    Toast.makeText(getApplicationContext(),"Number cannot be divided by 0",Toast.LENGTH_LONG).show();

                }




            }
        });
    }
}
