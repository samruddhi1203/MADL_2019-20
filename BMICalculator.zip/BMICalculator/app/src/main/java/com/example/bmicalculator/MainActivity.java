package com.example.bmicalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText ed1,ed2;
    Button b1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ed1=(EditText)findViewById(R.id.ed1);
        ed2=(EditText)findViewById(R.id.ed2);
        b1=(Button)findViewById(R.id.btn_calculate);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String value1=ed1.getText().toString();
                String value2=ed2.getText().toString();
                Double weight=Double.parseDouble(value1);
                Double height=Double.parseDouble(value2);
                Double ht_mt=height/100;
                Double BMI=(weight)/(ht_mt*ht_mt);
                Toast.makeText(getApplicationContext(),String.valueOf(BMI),Toast.LENGTH_LONG).show();
            }
        });

    }
}
