package edu.ritindia.rohit.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button button1,button2,button3,button4;
    EditText Text1,Text2;
    int a,b,add,sub,mult,div;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Text1=findViewById(R.id.Text1);
        Text2=findViewById(R.id.Text2);
        button1=findViewById(R.id.button1);
        button2=findViewById(R.id.button2);
        button3=findViewById(R.id.button3);
        button4=findViewById(R.id.button4);


        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s = Text1.getText().toString();
                String s1 = Text2.getText().toString();
                a = Integer.parseInt(s);
                b = Integer.parseInt(s1);
                add = a + b;
                Toast.makeText(getApplicationContext(), "Addition is:" + add, Toast.LENGTH_LONG).show();
            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s = Text1.getText().toString();
                String s1 = Text2.getText().toString();
                a = Integer.parseInt(s);
                b = Integer.parseInt(s1);
                sub = a - b;
                Toast.makeText(getApplicationContext(), "Subtraction is:" + sub, Toast.LENGTH_LONG).show();

            }
        });
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s = Text1.getText().toString();
                String s1 = Text2.getText().toString();
                a = Integer.parseInt(s);
                b = Integer.parseInt(s1);
                mult = a * b;
                Toast.makeText(getApplicationContext(), "Multiplication is:" + mult, Toast.LENGTH_LONG).show();

            }
        });
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s = Text1.getText().toString();
                String s1 = Text2.getText().toString();
                a = Integer.parseInt(s);
                b = Integer.parseInt(s1);
                div = a / b;
                Toast.makeText(getApplicationContext(), "Division is:" + div, Toast.LENGTH_LONG).show();

            }
        });


        }
    }

