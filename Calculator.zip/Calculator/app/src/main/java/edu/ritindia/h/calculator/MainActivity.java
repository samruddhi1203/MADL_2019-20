package edu.ritindia.h.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.net.sip.SipSession;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button b1,b2,b3,b4;
    EditText txtn1,txtn2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=findViewById(R.id.button1);
        b2=findViewById(R.id.button2);
        b3=findViewById(R.id.button3);
        b4=findViewById(R.id.button4);

        txtn1=findViewById(R.id.txt1);
        txtn2=findViewById(R.id.txt2);

        b1.setOnClickListener(this);
        b2.setOnClickListener(this);
        b3.setOnClickListener(this);
        b4.setOnClickListener(this);






    }

    @Override
    public void onClick(View v) {

        String num1=txtn1.getText().toString();
        String num2=txtn2.getText().toString();

        int a=Integer.parseInt(num1);
        int b=Integer.parseInt(num2);

        if(v.getId()==R.id.button1)
        {
          Toast.makeText(getApplicationContext(),"Addition is"+(a+b),Toast.LENGTH_LONG).show();

        }
        if(v.getId()==R.id.button2)
        {
            Toast.makeText(getApplicationContext(),"Substraction is"+(a-b),Toast.LENGTH_LONG).show();

        }

        if(v.getId()==R.id.button3)
        {
            Toast.makeText(getApplicationContext(),"Multiplication is"+(a*b),Toast.LENGTH_LONG).show();

        }
        if(v.getId()==R.id.button4)
        {
            Toast.makeText(getApplicationContext(),"Division is"+(a/b),Toast.LENGTH_LONG).show();

        }
    }
}


