package com.tonystark.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity  {
    Button b1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=findViewById(R.id.button1);

        Log.i("onCreate()","Activity created");
        Log.i("onStart()","Activity start");
        Log.i("onResume()","Activity Resume");
        Log.i("onPause()","Activity paused");
        Log.i("onStop()","Activity stoped");
        Log.i("onDestroy()","Activity destroyed");
        Log.i("onCreate()","Activity created");




    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
       // return super.onCreateOptionsMenu(menu);

        MenuInflater menuInflater= getMenuInflater();
        menuInflater.inflate(R.menu.file,menu);
        return super.onCreateOptionsMenu(menu);

    }

    public void onCLick(View view) {
        Intent i=new Intent(MainActivity.this,activity2.class);
        startActivity(i);
    }





}
