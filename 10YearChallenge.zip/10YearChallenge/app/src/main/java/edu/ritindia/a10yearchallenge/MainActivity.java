package edu.ritindia.a10yearchallenge;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener, View.OnClickListener {

   Spinner spinner;
   Button login,clear;
   EditText user,pass;
   public String item;
   ArrayAdapter<String> dataAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        spinner=findViewById(R.id.spinner);
        login=findViewById(R.id.btn_login);
        clear=findViewById(R.id.btn_clr);
        user=findViewById(R.id.username);
        pass=findViewById(R.id.password);

        spinner.setOnItemSelectedListener(this);

        List<String> type=new ArrayList<String>();
        type.add("Student");
        type.add("Faculty");
        type.add("Lab Assistant");

         dataAdapter=new ArrayAdapter<String>(this,R.layout.support_simple_spinner_dropdown_item,type);

        dataAdapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);

        spinner.setAdapter(dataAdapter);

        login.setOnClickListener(this);


    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
      item=parent.getItemAtPosition(position).toString();

        Toast.makeText(parent.getContext(),"Selected: "+item,Toast.LENGTH_LONG).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public void onClick(View v) {

        String s1,e1,l1,sp,ep,lp;
        s1="abc";
        sp="abc@123";
        e1="xyz";
        ep="xyz@123";
        l1="pqr";
        lp="pqr@123";

        String name=user.getText().toString();


        if(v.getId()==login.getId())
        {
            switch (item) {
                case "Student":

                        login_student();

                        break;



                case "Faculty":

                        login_faculty();

                        break;



                case "Lab Assistant":

                        login_lab();

                        break;



            }



        }
    }

    public void login_student()
    {
        String s1,sp;
        s1="mark";
        sp="mark@123";


        String name=user.getText().toString().trim();
        String pwd=pass.getText().toString().trim();

        if(name.equals(s1) && pwd.equals(sp))
        {
            Toast.makeText(getApplicationContext(),"Student username and password matched!",Toast.LENGTH_LONG).show();
            Intent intent = new Intent(MainActivity.this, Student.class);
            startActivity(intent);

        }
        else
        {
            Toast.makeText(getApplicationContext(),"Student username and password does't matched!",Toast.LENGTH_LONG).show();
        }

    }

    public void login_faculty()
    {
        String e1,ep;

        e1="elon";
        ep="elon@123";


        String name=user.getText().toString().trim();
        String pwd=pass.getText().toString().trim();

        if(name.equals(e1) && pwd.equals(ep))
        {
            Toast.makeText(getApplicationContext(),"Faculty username and password matched!",Toast.LENGTH_LONG).show();
            Intent intent1 = new Intent(MainActivity.this, Faculty.class);
            startActivity(intent1);

        }
        else
        {
            Toast.makeText(getApplicationContext(),"Faculty username and password does't matched!",Toast.LENGTH_LONG).show();
        }

    }

    public void login_lab()
    {
        String l1,lp;

        l1="jack";
        lp="jack@123";

        String name=user.getText().toString().trim();
        String pwd=pass.getText().toString().trim();

        if(name.equals(l1) && pwd.equals(lp))
        {
            Toast.makeText(getApplicationContext(),"Lab assistant username and password matched!",Toast.LENGTH_LONG).show();
            Intent intent2 = new Intent(MainActivity.this, Lab.class);
            startActivity(intent2);

        }
        else
        {
            Toast.makeText(getApplicationContext(),"Lab assistant username and password does't matched!",Toast.LENGTH_LONG).show();
        }

    }

}
