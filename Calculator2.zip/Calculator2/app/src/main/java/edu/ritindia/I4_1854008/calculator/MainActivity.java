package edu.ritindia.I4_1854008.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button add,sub,mul,div;
    EditText fn,sn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fn=findViewById(R.id.editText1);
        sn=findViewById(R.id.editText2);

        add=findViewById(R.id.btn_add);
        sub=findViewById(R.id.btn_sub);
        mul=findViewById(R.id.btn_mul);
        div=findViewById(R.id.btn_div);

        add.setOnClickListener(this);
        div.setOnClickListener(this);
        mul.setOnClickListener(this);
        sub.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(v.getId()==add.getId())
        {
            int n1,n2,res;
            n1=Integer.parseInt(fn.getText().toString());
            n2=Integer.parseInt(sn.getText().toString());

            res=n1+n2;

            Toast.makeText(getApplicationContext(),"Addition is: "+res,Toast.LENGTH_LONG).show();
        }

        if(v.getId()==sub.getId())
        {
            int n1,n2,res;
            n1=Integer.parseInt(fn.getText().toString());
            n2=Integer.parseInt(sn.getText().toString());

            res=n1-n2;

            Toast.makeText(getApplicationContext(),"Subtraction is: "+res,Toast.LENGTH_LONG).show();
        }

        if(v.getId()==mul.getId())
        {
            int n1,n2,res;
            n1=Integer.parseInt(fn.getText().toString());
            n2=Integer.parseInt(sn.getText().toString());

            res=n1*n2;

            Toast.makeText(getApplicationContext(),"Multiplication is: "+res,Toast.LENGTH_LONG).show();
        }

        if(v.getId()==div.getId())
        {
            float n1,n2,res=0;
            n1=Float.parseFloat(fn.getText().toString());
            n2=Float.parseFloat(sn.getText().toString());


            res=n1/n2;

            if(Float.isInfinite(res))
            {
                Toast.makeText(getApplicationContext(),"Number cannot be divided by zero",Toast.LENGTH_LONG).show();
            }
            else {
                Toast.makeText(getApplicationContext(),"Division is: "+res,Toast.LENGTH_LONG).show();
            }








        }
    }
}
