package com.example.quizapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {

    RadioButton r1,r2,r3,r4,r5,r6,r7,r8,r9,r10,r11,r12;
    RadioGroup rg;
    ConstraintLayout constraintLayout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        r1=findViewById(R.id.radioButton1);
        r2=findViewById(R.id.radioButton2);
        r3=findViewById(R.id.radioButton3);
        r4=findViewById(R.id.radioButton4);
        r5=findViewById(R.id.radioButton5);
        r6=findViewById(R.id.radioButton6);
        r7=findViewById(R.id.radioButton7);
        r8=findViewById(R.id.radioButton8);
        r9=findViewById(R.id.radioButton9);
        r10=findViewById(R.id.radioButton10);
        r11=findViewById(R.id.radioButton11);
        r12=findViewById(R.id.radioButton12);




        rg=findViewById(R.id.radiogroup1);

    }
    public void save(View v)
    {
        int count=0;
        if(r4.isChecked() )
        {
            count++;
        }
        if(r7.isChecked())
        {
            count++;
        }
        if(r11.isChecked())
        {
            count++;
        }
     /*  View view=findViewById(R.id.main_layout_id);
        String msg="Result is: " +count;
        int duration=Snackbar.LENGTH_LONG;
        showSnackbar(view, msg, duration);*/

     Snackbar.make(v,"Result is: "+count,Snackbar.LENGTH_LONG).show();

    }
    /*public void showSnackbar(View view, String msg, int duration)
    {
        final Snackbar snackbar = Snackbar.make(view, msg, duration);
        Snackbar.make(view, msg, duration).show();
    }*/
}
