package com.example.a10yearschallenge;

import androidx.appcompat.app.AppCompatActivity;

import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

public class Student_Page extends AppCompatActivity
{

    ImageButton b;
    ImageView i;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student__page);

        b = findViewById(R.id.imageButton);
        i = findViewById(R.id.imageView);
        b.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                i.setImageResource(R.drawable.slater);
                Toast.makeText(getApplicationContext(),"Photo of Student after 10 years",Toast.LENGTH_LONG).show();


            }
        });


    }


}
