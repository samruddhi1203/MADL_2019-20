package com.ritindia.prajkta.a10_year_challenge;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button button1;
    EditText editText1,editText2;
    Spinner spinner;
    ArrayAdapter arrayAdapter;
    String[] role={"Faculty","Lab Assistant","Student"};
    String selected_role;
    String stud_username="student",stud_password="student",faculty_username="faculty",faculty_password="faculty",assistant_username="assistant",assistanr_password="assistant";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText1=findViewById(R.id.editText1);
        editText2=findViewById(R.id.editText2);
        button1=findViewById(R.id.button1);
        spinner=findViewById(R.id.spinner1);
        arrayAdapter=new ArrayAdapter(this,android.R.layout.simple_selectable_list_item,role);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(arrayAdapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(position==0)
                {
                    selected_role=spinner.getSelectedItem().toString();
                }
                if(position==1)
                {
                    selected_role=spinner.getSelectedItem().toString();
                }
                if (position==2)
                {
                    selected_role=spinner.getSelectedItem().toString();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(selected_role=="Faculty")
                {
                    if (faculty_username.equals(editText1.getText().toString())&&faculty_password.equals(editText2.getText().toString()))
                    {
                        Toast.makeText(getApplicationContext(), "Login Successful", Toast.LENGTH_SHORT).show();
                        Intent I1=new Intent(getApplicationContext(),faculty_image.class);
                        startActivity(I1);
                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(), "Invalid Login!!!Please check the credentials", Toast.LENGTH_SHORT).show();
                    }
                }
                if (selected_role=="Student")
                {
                    if(stud_username.equals(editText1.getText().toString())&&stud_password.equals(editText2.getText().toString()))
                    {
                        Toast.makeText(getApplicationContext(), "Login Successful", Toast.LENGTH_SHORT).show();
                        Intent I1=new Intent(getApplicationContext(),student_image.class);
                        startActivity(I1);
                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(), "Invalid Login!!!Please check the credentials", Toast.LENGTH_SHORT).show();
                    }
                }
                if (selected_role=="Lab Assistant")
                {
                    if (assistant_username.equals(editText1.getText().toString())&&assistanr_password.equals(editText2.getText().toString()))
                    {
                        Toast.makeText(getApplicationContext(), "Login successful", Toast.LENGTH_SHORT).show();
                        Intent I1=new Intent(getApplicationContext(),Lab_Assistant_image.class);
                        startActivity(I1);
                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(), "Invalid Login!!!Please check the credentials", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

    }
}
