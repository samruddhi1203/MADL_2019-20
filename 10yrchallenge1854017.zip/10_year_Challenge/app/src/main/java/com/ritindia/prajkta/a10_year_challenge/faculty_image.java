package com.ritindia.prajkta.a10_year_challenge;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

public class faculty_image extends AppCompatActivity {

    ImageButton imageButton;
    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_faculty_image);
        imageButton=findViewById(R.id.imageButton_stud);
        imageView=findViewById(R.id.imageView1);
        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (v.getId()==R.id.imageButton_stud)
                {
                    imageView.setImageResource(R.drawable.e2);
                }
            }
        });
    }
}
