package com.ritindia.prajkta.a10_year_challenge;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

public class Lab_Assistant_image extends AppCompatActivity {

    ImageView imageView;
    ImageButton imageButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab__assistant_image);
        imageView=findViewById(R.id.imageView1);
        imageButton=findViewById(R.id.imageButton1);
        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(v.getId()==R.id.imageButton1)
                {
                    imageView.setImageResource(R.drawable.assistant2);
                }
            }
        });
    }
}
