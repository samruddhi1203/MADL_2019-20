package rit.edu.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    TextView e1, e2;
    Button b1, b2, b3, b4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        e1 = findViewById(R.id.e1);
        e2 = findViewById(R.id.e2);
        b1 = findViewById(R.id.b1);
        b2 = findViewById(R.id.b2);
        b3 = findViewById(R.id.b3);
        b4 = findViewById(R.id.b4);
        b1.setOnClickListener(this);
        b2.setOnClickListener(this);
        b3.setOnClickListener(this);
        b4.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        int num1 = Integer.parseInt(e1.getText().toString());
        int num2 = Integer.parseInt(e2.getText().toString());
        switch (v.getId()) {
            case R.id.b1:
                Toast.makeText(getApplicationContext(), "addition is" + (num1 + num2), Toast.LENGTH_LONG).show();
                break;
            case R.id.b2:
                Toast.makeText(getApplicationContext(), "sub is" + (num1 - num2), Toast.LENGTH_LONG).show();
                break;
            case R.id.b3:
                Toast.makeText(getApplicationContext(), "multi is" + (num1 * num2), Toast.LENGTH_LONG).show();
                break;
            case R.id.b4:
                Toast.makeText(getApplicationContext(), "div is" + (num1 / num2), Toast.LENGTH_LONG).show();
                break;
        }
    }
}