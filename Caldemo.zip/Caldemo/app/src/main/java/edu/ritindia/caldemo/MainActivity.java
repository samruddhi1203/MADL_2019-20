package edu.ritindia.caldemo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity  implements View.OnClickListener {
    EditText e1,e2;
    Button b1,b2,b3,b4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        e1=findViewById(R.id.n1);
        e2=findViewById(R.id.n2);
        b1=findViewById(R.id.add);
        b2=findViewById(R.id.sub);
        b3=findViewById(R.id.multi);
        b4=findViewById(R.id.div);

        b1.setOnClickListener(this);
        b2.setOnClickListener(this);
        b3.setOnClickListener(this);
        b4.setOnClickListener(this);



    }

    @Override
    public void onClick(View v) {
        int num1=Integer.parseInt(e1.getText().toString());
        int num2 =Integer.parseInt(e2.getText().toString());
        switch (v.getId())
        {
            case R.id.add:
                Toast.makeText(getApplicationContext(),"Addition is  " +(num1+num2),Toast.LENGTH_LONG).show();
                break;
            case R.id.sub :
                Toast.makeText(getApplicationContext(),"Subtration  is  " +(num1-num2),Toast.LENGTH_LONG).show();
                break;
            case R.id.multi :
                Toast.makeText(getApplicationContext(),"Multiplication  is  " +(num1*num2),Toast.LENGTH_LONG).show();
                break;
            case R.id.div :
                Toast.makeText(getApplicationContext(),"Division is  " +(num1/num2),Toast.LENGTH_LONG).show();
                break;
        }
    }
}
