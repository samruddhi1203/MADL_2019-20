package com.example.calci;

import androidx.appcompat.app.AppCompatActivity;


import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.view.View;


public class MainActivity extends AppCompatActivity {
    Button b1,b2,b3,b4;
    EditText ed1,ed2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ed1=(EditText)findViewById(R.id.ed1);
        ed2=(EditText)findViewById(R.id.ed2);
        b1 = (Button) findViewById(R.id.btn_add);
        b2 = (Button) findViewById(R.id.btn_sub);
        b3 = (Button) findViewById(R.id.btn_mul);
        b4 = (Button) findViewById(R.id.btn_div);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String value1=ed1.getText().toString();
                String value2=ed2.getText().toString();
                int a=Integer.parseInt(value1);
                int b=Integer.parseInt(value2);
                int sum=a+b;
                Toast.makeText(getApplicationContext(),String.valueOf(sum), Toast.LENGTH_LONG).show();
            }
        });


        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String value1=ed1.getText().toString();
                String value2=ed2.getText().toString();
                int a=Integer.parseInt(value1);
                int b=Integer.parseInt(value2);
                int sub=a-b;
                Toast.makeText(getApplicationContext(),String.valueOf(sub), Toast.LENGTH_LONG).show();
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String value1=ed1.getText().toString();
                String value2=ed2.getText().toString();
                int a=Integer.parseInt(value1);
                int b=Integer.parseInt(value2);
                int mul=a*b;
                Toast.makeText(getApplicationContext(),String.valueOf(mul), Toast.LENGTH_LONG).show();
            }
        });
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String value1=ed1.getText().toString();
                String value2=ed2.getText().toString();
                int a=Integer.parseInt(value1);
                int b=Integer.parseInt(value2);
                int div=a/b;
                Toast.makeText(getApplicationContext(),String.valueOf(div), Toast.LENGTH_LONG).show();
            }
        });
                              }

    }

