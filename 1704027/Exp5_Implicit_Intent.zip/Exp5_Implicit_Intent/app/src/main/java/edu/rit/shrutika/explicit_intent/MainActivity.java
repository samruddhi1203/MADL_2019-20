package edu.rit.shrutika.explicit_intent;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.CallLog;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button b1, b2, b3, b4, b5, b6, b7;
        final EditText ed;
        b1 = findViewById(R.id.button1);
        b2 = findViewById(R.id.button2);
        b3 = findViewById(R.id.button3);
        b4 = findViewById(R.id.button4);
        b5 = findViewById(R.id.button5);
        b6 = findViewById(R.id.button6);
        b7 = findViewById(R.id.button7);
        ed = (EditText) findViewById(R.id.editText);
        b1.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View arg0) {
                if (ed.getText() == null) {
                    Toast.makeText(getApplicationContext(), "Enter number", Toast.LENGTH_SHORT);
                } else {
                    public void onRequestPermissionsResult Object intrequestCode;
                    (intrequestCode, @NonNullString[] permissions, @NonNullint[] grantResults) {
                        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
                        if(requestCode==REQUEST_CALL)
                        {
                            if(grantResults.length>0 &&grantResults[0]== PackageManager.PERMISSION_GRANTED)
                            {
                                makePhonecall();
                            }
                            else
                            {
                                Toast.makeText(getApplicationContext(),"Reejcted Permission",Toast.LENGTH_LONG).show();
                            }
                        }
                    }


                    Button btnCall;
                    protected void onCreate(Bundle savedInstanceState) {
                        super.onCreate(savedInstanceState);
                        setContentView(R.layout.activity_main);
                        btnProgress=findViewById(R.id.button1);
                        btnCall=findViewById(R.id.button1);

                        btnCall.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                makePhonecall();

                            }
                        });
                    }

                    private void makePhonecall()
                    {
                        if(ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CALL_PHONE)!= PackageManager.PERMISSION_GRANTED)
                        {
                            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.CALL_PHONE},REQUEST_CALL);
                        }
                        else
                        {
                            Intent i=new Intent(Intent.ACTION_CALL, Uri.parse("tel:8830527631"));
                            startActivity(i);
                        }



                    }}
        }
                              });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            if(ed.getText() == null)
            {
                Toast.makeText( getApplicationContext(), "Enter number first", Toast.LENGTH_SHORT).show();
            }
            else
            {
            Uri u = Uri.parse("tel:" + ed.getText().toString());
            Intent i = new Intent(Intent.ACTION_DIAL,u);
            startActivity(i);
            }
            }
        });

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            Intent contact = new Intent();
            contact.setAction(Intent.ACTION_VIEW);
            contact.setType(ContactsContract.Contacts.CONTENT_TYPE);
            startActivity(contact);

            }
        });

        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            String url = "http://www.goggle.com";
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setData(Uri.parse(url));
            startActivity(i);
            }
        });

        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            //Uri allcalls = Uri.parse("Content://call_log/calls");
            Intent showcalllog = new Intent();
            showcalllog.setAction(Intent.ACTION_VIEW);
            showcalllog.setType(CallLog.Calls.CONTENT_TYPE);
            startActivity(showcalllog);
            }
        });

        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setAction(Intent.ACTION_VIEW);
                intent.setType("image/*");
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });

        b7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                //intent.setAction(Intent.ACTION_VIEW);

                startActivity(intent);
            }
        });

    }
}
