package edu.rit.shrutika.bmi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView ed1,ed2,t4,ed3;
    EditText t1,t2,t3;
    Button b1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        t1 = (EditText) findViewById(R.id.t1);
        t2 = (EditText) findViewById(R.id.t2);
        t3 = (EditText) findViewById(R.id.t3);
        b1 = findViewById(R.id.b1);
        ed1 = (TextView) findViewById(R.id.ed1);
        ed2 = (TextView) findViewById(R.id.ed2);
        ed3 = (TextView) findViewById(R.id.ed3);
        t4 = (TextView) findViewById(R.id.t4);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float weight = Float.parseFloat(t1.getText().toString());
                float height = Float.parseFloat(t2.getText().toString());
                float nume = height/100;
                float bmi = weight/(nume*nume) ;
                t3.setText(Float.toString(bmi));
                if(bmi <= 18.5)
                    ed3.setText("Underweight");
                else if ((18.5 < bmi) && (bmi <= 24.9))
                    ed3.setText("normal");
                else if((25.0 <= bmi) && (bmi <= 29.9))
                    ed3.setText("Overweight");
                else
                    ed3.setText("Obese");
            }
        });
    }
}
