package edu.rit.shrutika.quiz;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
public class MainActivity extends AppCompatActivity {
FloatingActionButton fb1;
RadioButton r1,r2,r3,rd1,rd2,rd3;
RadioGroup rg1,rg2,rg3;
int res =0  , q = 10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rg1 = findViewById(R.id.rg1);
        rg2 = findViewById(R.id.rg2);
        rg3 = findViewById(R.id.rg3);
        rd1 = findViewById(R.id.radioButton);
        rd2 = findViewById(R.id.radioButton7);
        rd3 = findViewById(R.id.radioButton9);
        int id1 = rg1.getCheckedRadioButtonId();
        //r1 = findViewById(id1);
        int id2 = rg2.getCheckedRadioButtonId();
        //r2 = findViewById(id2);
        int id3 = rg1.getCheckedRadioButtonId();
        //r3 = findViewById(id3);
        fb1 = findViewById(R.id.fb1);
        /*else
            res =res ;*/
        //final int finalRes = res;
        fb1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (rd1.isChecked())
                {
                    res = res + q;
                }
                if(rd2.isChecked()) {
                    res = q + res;
                }
                if(rd3.isChecked())
                {
                    res = q + res;
                }
            Snackbar.make(v,"Result:"+ res,Snackbar.LENGTH_LONG).show();
            res = 0;
            }
        });
    }
}

