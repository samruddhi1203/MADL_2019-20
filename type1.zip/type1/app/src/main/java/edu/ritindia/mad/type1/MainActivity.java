package edu.ritindia.mad.type1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button b1;
    TextView result;
    EditText w,h;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b1=findViewById(R.id.button);
        result=findViewById(R.id.tv3);
        w=findViewById(R.id.editText1);
        h=findViewById(R.id.editText2);
        b1.setOnClickListener(this);
        Toast.makeText(getApplicationContext(), "Developed by Nikita Hajare", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onClick(View v) {
        if(v.getId()==R.id.button)
        {
            Double BMI,weight = 0.0,height=0.0;

            weight=Double.parseDouble(w.getText().toString());
            height=Double.parseDouble(h.getText().toString());
            BMI = (weight/(height*height))*10000;


           if(BMI  < 18.5)
           {
               result.setText(String.valueOf(BMI)+" "+"Under weight");
           }
            if(BMI == 18.5 &&  BMI <= 24.9)
            {
                result.setText(String.valueOf(BMI)+" "+"Normal weight");
            }
            if(BMI == 25.0 &&  BMI <= 29.9)
            {
                result.setText(String.valueOf(BMI)+" "+"Over weight");
            }
            if(BMI == 30&&  BMI > 30)
            {
                result.setText(String.valueOf(BMI)+" "+"Obesity weight");
            }
        }
    }
}
