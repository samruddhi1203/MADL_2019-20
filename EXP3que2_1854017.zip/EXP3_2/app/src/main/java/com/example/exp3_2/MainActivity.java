package com.example.exp3_2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {

    RadioGroup rg1,rg2,rg3;
    RadioButton rb1,rb2,rb3,rb4,rb5,rb6,rb7,rb8,rb9,rb10,rb11,rb12;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rg1=findViewById(R.id.radioGroup1);
        rg2=findViewById(R.id.radioGroup2);
        rg3=findViewById(R.id.radioGroup3);

        rb1=findViewById(R.id.radioButton1);
        rb2=findViewById(R.id.radioButton2);
        rb3=findViewById(R.id.radioButton3);
        rb4=findViewById(R.id.radioButton4);
        rb5=findViewById(R.id.radioButton5);
        rb6=findViewById(R.id.radioButton6);
        rb7=findViewById(R.id.radioButton7);
        rb8=findViewById(R.id.radioButton8);
        rb9=findViewById(R.id.radioButton9);
        rb10=findViewById(R.id.radioButton10);
        rb11=findViewById(R.id.radioButton11);
        rb12=findViewById(R.id.radioButton12);

    }
    public void result(View view){
       int count=0;
        if(rb4.isChecked())
        {
            count++;
        }
        if(rb6.isChecked())
        {
            count++;
        }
        if(rb9.isChecked())
        {
            count++;
        }
        Snackbar.make(view,"Result is :"+count,Snackbar.LENGTH_LONG).show();


    }

}
