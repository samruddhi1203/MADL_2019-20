package com.example.menuapplication;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.zip.Inflater;

public class MainActivity extends AppCompatActivity {
    Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn=findViewById(R.id.btnClick);
        registerForContextMenu(btn);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id=item.getItemId();
        if(id==R.id.action_share){
            Intent Share =new Intent(Intent.ACTION_SEND);
            Share.setType("text/plain");
            Share.putExtra(Intent.EXTRA_SUBJECT,"Subject: Bonafide");
            Share.putExtra(Intent.EXTRA_TEXT,"from Samruddhi");
            //Intent.createChooser(Share,"Share via");

            startActivity(Share);
            Toast.makeText(getApplicationContext(),"Share",Toast.LENGTH_SHORT).show();
        }
        if(id==R.id.action_edit)
            Toast.makeText(getApplicationContext(),"Edit",Toast.LENGTH_SHORT).show();
        if(id==R.id.action_exit) {
            Toast.makeText(getApplicationContext(), "Exit", Toast.LENGTH_SHORT).show();
            finish();
        }
        if(id==R.id.action_new)
            Toast.makeText(getApplicationContext(),"New",Toast.LENGTH_SHORT).show();
        if(id==R.id.action_save)
            Toast.makeText(getApplicationContext(),"Save",Toast.LENGTH_SHORT).show();
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater menuInflater=getMenuInflater();
        menuInflater.inflate(R.menu.main_menu,menu);

    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        int id=item.getItemId();
        if(id==R.id.action_share){

            Toast.makeText(getApplicationContext(),"Share",Toast.LENGTH_SHORT).show();
        }
        if(id==R.id.action_edit)
            Toast.makeText(getApplicationContext(),"Edit",Toast.LENGTH_SHORT).show();
        if(id==R.id.action_exit) {
            Toast.makeText(getApplicationContext(), "Exit", Toast.LENGTH_SHORT).show();
            finish();
        }
        if(id==R.id.action_new)
            Toast.makeText(getApplicationContext(),"New",Toast.LENGTH_SHORT).show();
        if(id==R.id.action_save)
            Toast.makeText(getApplicationContext(),"Save",Toast.LENGTH_SHORT).show();
        return super.onContextItemSelected(item);
    }
}
