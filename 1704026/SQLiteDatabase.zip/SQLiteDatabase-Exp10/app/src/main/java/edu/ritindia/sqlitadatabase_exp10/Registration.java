package edu.ritindia.sqlitadatabase_exp10;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Registration extends AppCompatActivity {
    EditText name_reg,pass_reg,contact_reg;
    Button login_reg,reg_reg;
    DatabasesOp dbo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        name_reg = findViewById(R.id.Name_reg);
        pass_reg = findViewById(R.id.pass_reg);
        contact_reg = findViewById(R.id.contact_reg);
        login_reg = findViewById(R.id.log_reg);
        reg_reg = findViewById(R.id.reg_reg);
        dbo = new DatabasesOp(Registration.this);
        login_reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Registration.this,Login.class);
                startActivity(i);
            }
        });

        reg_reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    if(name_reg.getText().toString().isEmpty())
                    {
                        Toast.makeText(Registration.this, "this field cannot be empty", Toast.LENGTH_SHORT).show();
                    }
                    if(pass_reg.getText().toString().length() < 8 && pass_reg.getText().toString().isEmpty())
                    {
                        Toast.makeText(Registration.this, "Password length must be 8 characters", Toast.LENGTH_SHORT).show();
                    }
                    if(contact_reg.getText().toString().length()<10 && contact_reg.getText().toString().isEmpty())
                    {
                        Toast.makeText(Registration.this, "Contact must be 10 characters long", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        dbo.insertData(name_reg.getText().toString(), pass_reg.getText().toString(), contact_reg.getText().toString());
                        Toast.makeText(Registration.this, "Data inserted!!!", Toast.LENGTH_SHORT).show();
                    }
            }
        });
    }
}
