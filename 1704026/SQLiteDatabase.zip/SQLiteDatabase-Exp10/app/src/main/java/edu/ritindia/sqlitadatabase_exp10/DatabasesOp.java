package edu.ritindia.sqlitadatabase_exp10;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.security.PublicKey;

public class DatabasesOp extends SQLiteOpenHelper {
    public DatabasesOp(@Nullable Context context) {
        super(context, "Authentication.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table if not exists Userdata(Name varchar(40),Password varchar(8),Contact varchar(10))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists UserData");
        onCreate(db);
    }

    public void insertData(String name,String pass,String cont)
    {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("Name",name);
        cv.put("Password",pass);
        cv.put("Contact",cont);
        db.insert("UserData",null,cv);
    }
    public void updateData(String name,String pass)
    {
        SQLiteDatabase db= getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("Password",pass);
        db.update("UserData",cv,"name=?",new String[]{String.valueOf(name)});
    }
    public void deleteData(String name)
    {
        SQLiteDatabase db = getWritableDatabase();
        db.delete("UserData","name=?",new String[]{String.valueOf(name)});
    }
    public Cursor selectData( String name)
    {
        SQLiteDatabase db = getWritableDatabase();
        Cursor c = db.rawQuery("Select * from UserData where name=?",new String[]{String.valueOf(name)});
        return c;
    }
}
