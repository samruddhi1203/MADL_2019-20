package edu.ritindia.sqlitadatabase_exp10;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Login extends AppCompatActivity {
    Button login,register,delete,update;
    EditText name,password;
    DatabasesOp dbo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        name = findViewById(R.id.Name_edit);
        password = findViewById(R.id.pass_edit);

        login = findViewById(R.id.Login_btn);
        register = findViewById(R.id.reg_btn);
        delete = findViewById(R.id.delete_btn);
        update = findViewById(R.id.update_btn);
        dbo = new DatabasesOp(Login.this);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) throws SQLException {
                String n1 = name.getText().toString(), pass = "";
                Cursor c1 = dbo.selectData(n1);
                if (c1.moveToFirst())
                {
                    do
                    {
                        pass = c1.getString(1);

                    }while (c1.moveToNext());
                }
                if( pass.equals(password.getText().toString()))
                {
                    Intent i = new Intent(Login.this,MainActivity.class);
                    startActivity(i);
                    Toast.makeText(Login.this, "name:"+n1+"pass:"+pass, Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(Login.this, "Incorrect name or password", Toast.LENGTH_SHORT).show();
                }
            }
        });
         register.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 Intent i = new Intent(Login.this,Registration.class);
                 startActivity(i);
             }
         });
         delete.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                dbo.deleteData(name.getText().toString());
                 Toast.makeText(Login.this, "Record deleted Successfully!!", Toast.LENGTH_SHORT).show();

             }
         });
         update.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                String nm = name.getText().toString();
                String p = password.getText().toString();
                dbo.updateData(nm,p);
                 Toast.makeText(Login.this, "Password updated successfully", Toast.LENGTH_SHORT).show();
             }
         });
    }
}
