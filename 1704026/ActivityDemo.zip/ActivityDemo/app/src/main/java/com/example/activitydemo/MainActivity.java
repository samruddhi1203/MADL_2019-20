package com.example.activitydemo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.i("onCreate()","activity is created");
    }
    @Override
    protected void onStart() {
        super.onStart();
        Log.i("onStart()","activity is started");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.i("onResume()","activity is resumed");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.i("onPause()","activity is paused");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.i("onStop()","activity is stopped");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i("onDestroy()","activity is destroyed");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.i("onRestart()","activity is restarted");
    }

    public void second(View view) {
        Intent i=new Intent(MainActivity.this,SecondActivity.class);
        startActivity(i);
    }
}
