package com.example.quizapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class Q1 extends AppCompatActivity
{
    Button btnClear;
    FloatingActionButton btnFA;
    RadioGroup rb1,rb2,rb3;
    RadioButton rAns1,rAns2,rAns3,r1,r2,r3,r4,r5,r6,r7,r8,r9,r10,r11,r12;
    String ans1="D - All of Above",ans2="C - A and B",ans3="A - A class that can create only one object";
    static int ctr=0;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_q1);
        rb1=findViewById(R.id.rbg1);
        rb2=findViewById(R.id.rbg2);
        rb3=findViewById(R.id.rbg3);

        r1=findViewById(R.id.rb1);
        r2=findViewById(R.id.rb2);
        r3=findViewById(R.id.rb3);
        r4=findViewById(R.id.rb4);
        r5=findViewById(R.id.rb5);
        r6=findViewById(R.id.rb6);
        r7=findViewById(R.id.rb7);
        r8=findViewById(R.id.rb8);
        r9=findViewById(R.id.rb9);
        r10=findViewById(R.id.rb10);
        r11=findViewById(R.id.rb11);
        r12=findViewById(R.id.rb12);

        btnClear=findViewById(R.id.btnClear);
        btnFA=findViewById(R.id.btnFA);

        btnFA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int id1=rb1.getCheckedRadioButtonId();
                rAns1=findViewById(id1);
                int id2=rb2.getCheckedRadioButtonId();
                rAns2=findViewById(id2);
                int id3=rb3.getCheckedRadioButtonId();
                rAns3=findViewById(id3);
                String a1=rAns1.getText().toString();
                String a2=rAns2.getText().toString();
                String a3=rAns3.getText().toString();
                ctr=0;
                if(ans1.equals(a1))
                {
                    ctr++;
                }
                if(ans2.equals(a2))
                {
                    ctr++;
                }
                if(ans3.equals(a3))
                {
                    ctr++;
                }
                Toast.makeText(Q1.this,"Result Marks="+ctr,Toast.LENGTH_LONG).show();
                ctr=0;
            }
        });
        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                r1.setSelected(false);
                r2.setSelected(false);
                r3.setSelected(false);
                r4.setSelected(false);
                r5.setSelected(false);
                r6.setSelected(false);
                r7.setSelected(false);
                r8.setSelected(false);
                r9.setSelected(false);
                r10.setSelected(false);
                r11.setSelected(false);
                r12.setSelected(false);
            }
        });

    }
    void Ans()
    {

    }
}
