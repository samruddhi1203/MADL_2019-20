package edu.ritindia.amrut.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button add;
    Button sub,mul,div;
    EditText fn,sn;
    TextView res;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fn=findViewById(R.id.editText1);
        sn=findViewById(R.id.editText2);
        add=findViewById(R.id.button1);
        sub=findViewById(R.id.button2);
        mul=findViewById(R.id.button3);
        div=findViewById(R.id.button4);
        res=findViewById(R.id.textView);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s1=fn.getText().toString();
                String s2=sn.getText().toString();
                int i1=Integer.parseInt(s1);
                int i2=Integer.parseInt(s2);
                int i3=i1+i2;
                //res.setText(i1+i2);
                Toast.makeText(getApplicationContext(),i3,Toast.LENGTH_LONG).show();
            }
        });


    }
}
