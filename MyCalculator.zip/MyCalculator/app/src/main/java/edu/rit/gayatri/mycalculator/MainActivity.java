package edu.rit.gayatri.mycalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    Button btn1, btn2, btn3, btn4;
    EditText ed1, ed2, ed3;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ed1 = findViewById(R.id.ed1);
        ed2 = findViewById(R.id.ed2);
        ed3 = findViewById(R.id.ed3);

        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.btn2);
        btn3 = findViewById(R.id.btn3);
        btn4 = findViewById(R.id.btn4);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float n1 =  Float.parseFloat(ed1.getText().toString());
                float n2 = Float.parseFloat(ed2.getText().toString());
                float r =  n1 + n2 ;
                ed3.setText(String.valueOf(r));
            }
        });


        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float n1 =  Float.parseFloat(ed1.getText().toString());
                float n2 =  Float.parseFloat(ed2.getText().toString());
                float r =  n1 - n2;
                ed3.setText(String.valueOf(r));
            }
        });


        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float n1 = Float.parseFloat(ed1.getText().toString());
                float n2 =  Float.parseFloat(ed2.getText().toString());
                float r =  n1 * n2;
                ed3.setText(String.valueOf(r));
            }
        });


        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float n1 =  Float.parseFloat(ed1.getText().toString());
                float n2 =  Float.parseFloat(ed2.getText().toString());
                if(n2==0)
                {
                 String r1="infinite";
                    ed3.setText(r1.toString());

                }
                float r =  n1 /  n2;
                ed3.setText(String.valueOf(r));
            }
        });


    }
}