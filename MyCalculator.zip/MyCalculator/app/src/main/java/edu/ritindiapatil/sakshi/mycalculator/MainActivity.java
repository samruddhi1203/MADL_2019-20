package edu.ritindiapatil.sakshi.mycalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    Button b1,b2,b3,b4;
    EditText t1,t2;
    int result,a,b,c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        b1=findViewById(R.id.add);
        b2=findViewById(R.id.sub);
        b3=findViewById(R.id.mul);
        b4=findViewById(R.id.div);

        t1=findViewById(R.id.txt1);
        t2=findViewById(R.id.txt2);


        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a=Integer.parseInt(t1.getText().toString());
                b=Integer.parseInt(t2.getText().toString());
                c=a+b;
                Toast.makeText(getApplicationContext(),"addition is "+c,Toast.LENGTH_LONG).show();
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a=Integer.parseInt(t1.getText().toString());
                b=Integer.parseInt(t2.getText().toString());
                c=a-b;
                Toast.makeText(getApplicationContext(),"substraction is "+c,Toast.LENGTH_LONG).show();
            }
        });

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a=Integer.parseInt(t1.getText().toString());
                b=Integer.parseInt(t2.getText().toString());
                c=a*b;
                Toast.makeText(getApplicationContext(),"multiplication is "+c,Toast.LENGTH_LONG).show();
            }
        });

        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a=Integer.parseInt(t1.getText().toString());
                b=Integer.parseInt(t2.getText().toString());
                c=a/b;
                Toast.makeText(getApplicationContext(),"division is "+c,Toast.LENGTH_LONG).show();
            }
        });
    }
}
