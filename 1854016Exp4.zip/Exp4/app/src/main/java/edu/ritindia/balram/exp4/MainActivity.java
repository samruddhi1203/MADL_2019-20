package edu.ritindia.balram.exp4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button bb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bb=findViewById(R.id.button2);
        registerForContextMenu(bb);

        Log.i("onCreate","Activity created");
    }

    @Override
    protected void onStart() {
        super.onStart();

        Log.i("onStart","Activity Strated");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

           MenuInflater mf= getMenuInflater();
             mf.inflate(R.menu.ritmenu,menu);



        return super.onCreateOptionsMenu(menu);

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch(item.getItemId())
        {
            case R.id.item1:
            {
               Intent i=new Intent(MainActivity.this,SecondActivity.class);
               startActivity(i);
                break;
            }

            case 2:
            {
              Toast.makeText(getApplicationContext(),"clicked to edit ",Toast.LENGTH_LONG).show();

                break;
            }

            case 3:
            {
       Toast.makeText(getApplicationContext(),"clicked to view",Toast.LENGTH_LONG).show();

                break;
            }
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onStop() {
        super.onStop();

        Log.i("onStop","Activity Stopped");
    }

    @Override
    protected void onPause() {
        super.onPause();

        Log.i("onPause","Activity paused");
    }


    @Override
    protected void onResume() {
        super.onResume();

        Log.i("onResume","Activity resumed");
    }


    @Override
    protected void onRestart() {
        super.onRestart();

        Log.i("onRestat","Activity restarted");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);

        super.onCreateContextMenu(menu, v, menuInfo);
        menu.setHeaderTitle("Context Menu");
        menu.add(0, v.getId(), 0, "Upload");
        menu.add(0, v.getId(), 0, "Search");
        menu.add(0, v.getId(), 0, "Share");
        menu.add(0, v.getId(), 0, "Bookmark");

    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {


        Toast.makeText(getApplicationContext(),item.getTitle(),Toast.LENGTH_SHORT).show();
        return super.onContextItemSelected(item);



    }
}
