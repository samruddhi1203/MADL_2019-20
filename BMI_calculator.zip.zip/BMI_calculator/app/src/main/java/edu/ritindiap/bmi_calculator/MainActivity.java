package edu.ritindiap.bmi_calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button b1;
    EditText e1,e2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        e1=findViewById(R.id.editText1);
        e2=findViewById(R.id.editText2);
        b1=findViewById(R.id.button1);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float weight=Float.parseFloat(e1.getText().toString());
                float height=Float.parseFloat(e2.getText().toString())/100;
                float bmi_result=bmicalculator(weight,height);
                String bmi_interprt=bmiinterpretation(bmi_result);
                Toast.makeText(getApplicationContext(), ""+bmi_result+" "+bmi_interprt, Toast.LENGTH_SHORT).show();
            }
        });
    }
    public float bmicalculator(float weight,float height)
    {
        return (float) (weight)/(height*height);
    }
    public String bmiinterpretation(float bmi_result)
    {
      if (bmi_result<16)
      {
          return "severe thinness";
      }
      else if (bmi_result<17)
      {
          return "Moderate thinness";
      }
      else if(bmi_result<18.5)
      {
          return "mild thinness";
      }
      else if(bmi_result<25)
      {
          return "Normal";
      }
      else if (bmi_result<30)
      {
          return "overweight";
      }
      else
          return "obese";
    }
}
