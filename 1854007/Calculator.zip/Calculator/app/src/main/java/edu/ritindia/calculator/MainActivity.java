package edu.ritindia.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    EditText fn,sn;
    Button b1,b2,b3,b4;
    int num1,num2;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fn = findViewById(R.id.First_no);
        sn = findViewById(R.id.Sec_no);
        b1 = findViewById(R.id.add);
        b1.setOnClickListener(this);

        b2 = findViewById(R.id.sub);
        b2.setOnClickListener(this);

        b3 = findViewById(R.id.mul);
        b3.setOnClickListener(this);

        b4 = findViewById(R.id.div);
        b4.setOnClickListener(this);
      /*  b1 = findViewById(R.id.add);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                num1 = Integer.parseInt(fn.getText().toString());
                num2 = Integer.parseInt(sn.getText().toString());
                Toast.makeText(getApplicationContext(), "Addition is :"+(num1+num2), Toast.LENGTH_SHORT).show();
            }
        });
        b2 = findViewById(R.id.sub);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                num1 = Integer.parseInt(fn.getText().toString());
                num2 = Integer.parseInt(sn.getText().toString());
                Toast.makeText(getApplicationContext(), "Substraction is :"+(num1-num2), Toast.LENGTH_SHORT).show();
            }
        });
        b3 = findViewById(R.id.mul);
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                num1 = Integer.parseInt(fn.getText().toString());
                num2 = Integer.parseInt(sn.getText().toString());
                Toast.makeText(getApplicationContext(), "Multiplication is :"+(num1*num2), Toast.LENGTH_SHORT).show();
            }
        });
        b4 = findViewById(R.id.div);
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                num1 = Integer.parseInt(fn.getText().toString());
                num2 = Integer.parseInt(sn.getText().toString());
                Toast.makeText(getApplicationContext(), "Division is :"+(num1/num2), Toast.LENGTH_SHORT).show();
            }
        });*/


    }

    @Override
    public void onClick(View v) {
        int  num1 = Integer.parseInt(fn.getText().toString());
        int num2 = Integer.parseInt(sn.getText().toString());
        int r;
        if(v.getId() == R.id.add)
        {
            Toast.makeText(getApplicationContext(), "Addition : "+(num1+num2), Toast.LENGTH_SHORT).show();
//            r=num1+num2;
//            EditText editText = (EditText)findViewById(R.id.res_view);
//            editText.setText(String.valueOf(r));
        }
        if(v.getId() == R.id.sub)
        {
            Toast.makeText(getApplicationContext(), "Substraction : "+(num1-num2), Toast.LENGTH_SHORT).show();
        }
        if(v.getId() == R.id.mul)
        {
            Toast.makeText(getApplicationContext(), "Multiplication : "+(num1*num2), Toast.LENGTH_SHORT).show();
        }
        if(v.getId() == R.id.div)
        {
            Toast.makeText(getApplicationContext(), "Division : "+(num1/num2), Toast.LENGTH_SHORT).show();
        }
    }
}
