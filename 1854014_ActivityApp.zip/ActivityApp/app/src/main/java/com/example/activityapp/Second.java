package com.example.activityapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class Second extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        Button b=findViewById(R.id.button);
    }

    public void Back(View v)
    {
        Intent i=new Intent(Second.this,MainActivity.class);
        startActivity(i);
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.i("onStart","Second Activity Started");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.i("onResume","Second Activity Resumed");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.i("onPause","Second Activity Paused");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.i("onStop","Second Activity Stopped");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i("onDestroy","Second Activity Destroyed");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.i("onRestart","Activity Restarted");
    }

}
