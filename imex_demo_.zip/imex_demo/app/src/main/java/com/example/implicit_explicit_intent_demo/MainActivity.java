package com.example.implicit_explicit_intent_demo;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    Button btn_call, btn_dialpad, btn_camera, btn_browser, btn_calllog, btn_gallery, btn_contact;
    EditText editText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn_call = findViewById(R.id.bcall);
        btn_dialpad = findViewById(R.id.bdialpad);
        btn_calllog = findViewById(R.id.bcalllog);
        btn_browser = findViewById(R.id.bbrowser);
        btn_camera = findViewById(R.id.bcamera);
        btn_contact = findViewById(R.id.bcontact);
        btn_gallery = findViewById(R.id.bgallery);
        editText=findViewById(R.id.editText);

        btn_call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i1=new Intent();
                i1.setAction(Intent.ACTION_CALL);
                i1.setData(Uri.parse("tel:"+editText.getText()));
                startActivity(i1);
            }
        });

        btn_dialpad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i1=new Intent();
                i1.setAction(Intent.ACTION_DIAL);
                i1.setData(Uri.parse("tel:"+editText.getText()));
                startActivity(i1);
            }
        });

        btn_calllog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i1 = new Intent();
                i1.setAction(Intent.ACTION_VIEW);
                i1.setData(Uri.parse("content://call_log/calls/"));
                startActivity(i1);
            }
        });

        btn_browser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i1 = new Intent();
                i1.setAction(Intent.ACTION_VIEW);
                i1.setData(Uri.parse("https://www.google.com"));
                startActivity(i1);
                }
        });

        btn_contact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i1 = new Intent();
                i1.setAction(Intent.ACTION_VIEW);
                i1.setData(Uri.parse("content://contacts/people/"));
                startActivity(i1);
            }
        });

        btn_gallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i1 = new Intent();
                i1.setAction(Intent.ACTION_VIEW);
                i1.setData(Uri.parse("content://media/external/images/media/"));
                startActivity(i1);
            }
        });

        btn_camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i1 = new Intent();
                i1.setAction(MediaStore.ACTION_IMAGE_CAPTURE);

                startActivity(i1);
            }
        });

    }
}
