package com.example.bmi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText e1 = (EditText) findViewById(R.id.editText);
        final EditText e2 = (EditText) findViewById(R.id.editText2);
        //final TextView tv4 = (TextView) findViewById(R.id.textView4);
        Button btn = (Button) findViewById(R.id.button);

        btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                    String str1 = e1.getText().toString();
                    String str2 = e2.getText().toString();

                    float height = Float.parseFloat(str1) / 100;
                    float weight = Float.parseFloat(str2);

                    float bmi = calculateBMI(height,weight);
                   // tv4.setText(String.valueOf(bmi));
                    Toast.makeText(getApplicationContext(),"Reasult is :"+bmi,Toast.LENGTH_SHORT).show();
            }

        });

    }
                private float calculateBMI(float height,float weight)
                {
                    return (float)(weight / (height*height));

                }
}
