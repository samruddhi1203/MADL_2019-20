package com.xyz.bmi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    EditText ed1,ed2;
    Button b1;
    double h,w,r;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ed1.findViewById(R.id.editText1);
        ed2.findViewById(R.id.editText2);
        b1.findViewById(R.id.button);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                w=Integer.parseInt(ed1.getText().toString());

                h=Integer.parseInt(ed2.getText().toString());

                h=h/100;
                r=w/(h*h);

                Toast.makeText(getApplicationContext(),"BMI is "+r,Toast.LENGTH_LONG).show();

            }
        });





    }

}
