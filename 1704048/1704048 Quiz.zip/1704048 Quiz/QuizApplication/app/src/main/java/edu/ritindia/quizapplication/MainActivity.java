package edu.ritindia.quizapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {
    RadioGroup rg_q1,rg_q2,rg_q3;
    RadioButton ans1,ans2,ans3;
    int idQue1,idQue2,idQue3,res = 0;
    String a1,a2,a3;
    String q1_ans ="4) Android Inc.",q2_ans="a) Linux",q3_ans="d) /res/layout";
    FloatingActionButton fab;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rg_q1 = findViewById((R.id.radioGroup1));
        rg_q2 = findViewById((R.id.radioGroup2));
        rg_q3 = findViewById((R.id.radioGroup3));

        fab= findViewById(R.id.floatingActionButton);

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    idQue1 = rg_q1.getCheckedRadioButtonId();
                    idQue2 = rg_q2.getCheckedRadioButtonId();
                    idQue3 = rg_q3.getCheckedRadioButtonId();
                    ans1 = findViewById(idQue1);
                    ans2 = findViewById(idQue2);
                    ans3 = findViewById(idQue3);
                    a1 = ans1.getText().toString();
                    a2 = ans2.getText().toString();
                    a3 = ans3.getText().toString();
                    if (q1_ans.equals(a1)) {
                        res++;
                    }
                    if (q2_ans.equals(a2)) {
                        res++;
                    }
                    if (q3_ans.equals(a3)) {
                        res++;
                    }
                    Snackbar.make(v, "Score :" + res, Snackbar.LENGTH_LONG).show();
                }
                catch (Exception e)
                {
                    Toast.makeText(MainActivity.this, " Choose your answers", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
