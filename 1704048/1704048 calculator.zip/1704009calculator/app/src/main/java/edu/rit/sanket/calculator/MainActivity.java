package edu.rit.sanket.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button button1, button2, button3, button4;
    EditText editText, editText2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button1=findViewById(R.id.button1);
        button2=findViewById(R.id.button2);
        button3=findViewById(R.id.button3);
        button4=findViewById(R.id.button4);
        editText = findViewById(R.id.editText);
        editText2 =findViewById(R.id.editText2);

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s1 = editText.getText().toString();
                String s2 = editText2.getText().toString();
                int a = Integer.parseInt(s1);
                int b = Integer.parseInt(s2);
                int add = a + b;
                Toast.makeText(getApplicationContext(),"Addition is : "+ add,Toast.LENGTH_SHORT).show();
            }
        });


        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s3 = editText.getText().toString();
                String s4 = editText2.getText().toString();
                int c = Integer.parseInt(s3);
                int d = Integer.parseInt(s4);
                int sub = c - d;
                Toast.makeText(getApplicationContext(),"Substraction is : "+ sub ,Toast.LENGTH_SHORT).show();
            }
        });


        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s5 = editText.getText().toString();
                String s6 = editText2.getText().toString();
                int e = Integer.parseInt(s5);
                int f = Integer.parseInt(s6);
                int multi = e * f;
                Toast.makeText(getApplicationContext(),"Multiplication is : "+ multi ,Toast.LENGTH_SHORT).show();
            }
        });


        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s7 = editText.getText().toString();
                String s8 = editText2.getText().toString();
                int g = Integer.parseInt(s7);
                int h =Integer.parseInt(s8);
                double div = g / h;
                Toast.makeText(getApplicationContext(),"Division is : "+ div,Toast.LENGTH_SHORT).show();
            }
        });

    }
}
