package rit.edu.akshay.music;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public  void  playclick (View view)
    {
        Intent i=new Intent(MainActivity.this,playservice.class);
        startService(i);
    }
    public  void pauseclick(View view)
    {
        Intent i=new Intent(MainActivity.this,playservice.class);
        stopService(i);
    }
    public  void  stopclick(View view)
    {
        Intent i=new Intent(MainActivity.this,playservice.class);
        stopService(i);
    }

}
