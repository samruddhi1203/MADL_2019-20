package rit.edu.akshay.music;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.IBinder;
import android.widget.Toast;

public class playservice extends Service {

    MediaPlayer mp;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    public void onCreate() {
        super.onCreate();
        mp = MediaPlayer.create(this, R.raw.sai);

    }
    public int onStartCommand(Intent intent,int flags,int StartId) {
        mp.start();
        Toast.makeText(this, "music is start", Toast.LENGTH_LONG).show();
        return START_STICKY;

    }

    public void onDestroy() {
        mp.stop();
        Toast.makeText(this, "music is stop", Toast.LENGTH_LONG).show();
        super.onDestroy();

    }

}
