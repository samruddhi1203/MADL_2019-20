package com.example.quizapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {
    FloatingActionButton floatingActionButton;
    RadioButton r1,r2,r3,r4,r5,r6,r7,r8,r9,r10,r11,r12;
    RadioGroup rg1,rg2,rg3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        r1=findViewById(R.id.radioButton1);
        r2=findViewById(R.id.radioButton2);
        r3=findViewById(R.id.radioButton4);
        r4=findViewById(R.id.radioButton4);

        r5=findViewById(R.id.radioButton5);
        r6=findViewById(R.id.radioButton6);
        r7=findViewById(R.id.radioButton7);
        r8=findViewById(R.id.radioButton8);

        r9=findViewById(R.id.radioButton9);
        r10=findViewById(R.id.radioButton10);
        r11=findViewById(R.id.radioButton11);
        r12=findViewById(R.id.radioButton12);

        floatingActionButton=findViewById(R.id.floatingActionButton);
        rg1=findViewById(R.id.radioGroup1);
        rg2=findViewById(R.id.radioGroup2);
        rg3=findViewById(R.id.radioGroup3);

    }

    public void Show(View view)
    {
        int cnt=0;

        if(r4.isChecked())
        {
            cnt++;
        }

        if(r6.isChecked())
        {
            cnt++;
        }

        if(r9.isChecked())
        {
            cnt++;
        }

        Snackbar.make(view,"Result:"+cnt,Snackbar.LENGTH_LONG).show();
    }

}
