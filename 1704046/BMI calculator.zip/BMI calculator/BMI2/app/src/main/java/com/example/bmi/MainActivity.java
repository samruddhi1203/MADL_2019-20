package com.example.bmi;



import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText edt1,edt2,edt3;
    Button btn1;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edt1=findViewById(R.id.edt1);
        edt2=findViewById(R.id.edt2);
        edt3=findViewById(R.id.edt3);
        btn1=findViewById(R.id.btn1);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Float n1=Float.parseFloat(edt1.getText().toString());
                Float n2=Float.parseFloat(edt2.getText().toString());
                Float h=n2/100;
                Float res=n1/(h*h);
                if(res<18.5)
                {
                    String res1="Underweight "+res;
                    edt3.setText(res1);
                }
                else if(res>18.5 && res<25)
                {
                    String res2="Normal  "+res;
                    edt3.setText(res2);
                }
                else if(res>25)
                {
                    String res3="Overweight "+res;
                    edt3.setText(res3);
                }

            }
        });
    }
}
