package edu.ritindia.a10yearschallenge;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

public class ImageChange extends AppCompatActivity {
    ImageView image;
    ImageButton btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_change);
        image = findViewById(R.id.iv_mini);
        btn = findViewById(R.id.btn_click_student);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(v.getId() == R.id.btn_click_student)
                {
                    image.setImageResource(R.drawable.mini2);
                }
            }
        });
    }
}
