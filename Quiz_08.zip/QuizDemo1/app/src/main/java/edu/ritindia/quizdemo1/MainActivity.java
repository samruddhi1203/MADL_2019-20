package edu.ritindia.quizdemo1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity extends AppCompatActivity {
   TextView tvQ1,tvQ2,tvQ3;
   RadioGroup rg1,rg2,rg3;
   RadioButton b1,b2,b3;
   FloatingActionButton fabCal;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvQ1=findViewById(R.id.tvQ1);
        tvQ2=findViewById(R.id.tvQ2);
        tvQ3=findViewById(R.id.tvQ3);
        rg1=findViewById(R.id.rg1);
        rg2=findViewById(R.id.rg2);
        rg3=findViewById(R.id.rg3);
       // b1=findViewById(R.id.b1);
        fabCal= findViewById(R.id.fabCal);
        fabCal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int Count=0;
                int id=rg1.getCheckedRadioButtonId();
                b1=findViewById(id);
                int id1=rg2.getCheckedRadioButtonId();
                b2=findViewById(id1);
                int id2=rg3.getCheckedRadioButtonId();
                b3=findViewById(id2);

                if(id==R.id.rb12 ) {
                    Count++;

                }
                if (id2 == R.id.rb31) {
                     Count++;
                    }
                   if(id1==R.id.rb23) Count++;




               Toast.makeText(getApplicationContext(),"Ur Score is :"+Count,Toast.LENGTH_LONG).show();
               // Toast.makeText(getApplicationContext(),"Ur answer is "+b1.getText().toString(),Toast.LENGTH_LONG).show();


            }
        });

    }
    }
