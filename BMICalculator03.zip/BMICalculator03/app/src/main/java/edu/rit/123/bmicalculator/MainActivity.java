package edu.rit.123.bmicalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {


    EditText ed1,ed2;
    Button  btn1;
    Double res;
    @Override
    protected void onCreate(Bundle savedInstanceState)  {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ed1=findViewById(R.id.editText1);
        ed2=findViewById(R.id.editText2);
        btn1=findViewById(R.id.button);

        btn1.setOnClickListener(this);




    }

    @Override
    public void onClick(View v) {

        if (v.getId()==R.id.button)
        {
            res=(Double.parseDouble(ed1.getText().toString())/(Double.parseDouble(ed2.getText().toString())*Double.parseDouble(ed2.getText().toString())));
            if (res>= 30)
            {
                Toast.makeText(this, res+" (Obese)", Toast.LENGTH_SHORT).show();
            }
            else if (res>=25 && res<30)
            {
                Toast.makeText(this, res+" (Overweight)", Toast.LENGTH_SHORT).show();
            }
            else if (res>=18.5 && res <25)
            {
                Toast.makeText(this, res+" (Healthy Weight)", Toast.LENGTH_SHORT).show();
            }
            else if (res<18.5)
            {
                Toast.makeText(this, res+" (Underweight)", Toast.LENGTH_SHORT).show();

            }
            else
            {
                Toast.makeText(this, "Inappropriate Values", Toast.LENGTH_SHORT).show();

            }

        }
    }
}
