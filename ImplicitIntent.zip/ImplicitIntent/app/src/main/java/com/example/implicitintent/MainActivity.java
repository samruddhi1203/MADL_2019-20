package com.example.implicitintent;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener
{

    Button b1,b2,b3,b4,b5;
    EditText ed1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b1=findViewById(R.id.button);
        b1.setOnClickListener(this);

        b2=findViewById(R.id.button2);
        b2.setOnClickListener(this);

        b3=findViewById(R.id.button3);
        b3.setOnClickListener(this);

        b4=findViewById(R.id.button4);
        b4.setOnClickListener(this);

        b5=findViewById(R.id.button5);
        b5.setOnClickListener(this);

        ed1=findViewById(R.id.editText);
    }

    @Override
    public void onClick(View v)
    {
        if(v.getId()==R.id.button)
        {
            try
            {
                Intent i1=new Intent(Intent.ACTION_DIAL, Uri.parse("tel:+91 "+ed1.getText().toString()));
                startActivity(i1);
            }
            catch (Exception e)
            {
                Toast.makeText(this,"Error O",Toast.LENGTH_LONG).show();
            }

        }

        if(v.getId()==R.id.button2)
        {
            Intent i3=new Intent(Intent.ACTION_VIEW,Uri.parse("content://media/external/images/media/"));
            startActivity(i3);
        }

        if(v.getId()==R.id.button4)
        {
            Intent i2=new Intent(Intent.ACTION_VIEW,Uri.parse("http://www.google.com"));
            startActivity(i2);
        }

        if(v.getId()==R.id.button3)
        {
            Intent i3=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivity(i3);
        }

        if(v.getId()==R.id.button5)
        {
            Intent i3=new Intent(Intent.ACTION_VIEW,Uri.parse("content://call_log/calls/"));
            startActivity(i3);
        }
    }


}
