package com.xyz.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
Button b1,b2,b3,b4;
EditText e1,e2;
int a,b;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        e1=findViewById(R.id.e1);
        e2=findViewById(R.id.e2);
        b1=findViewById(R.id.b1);
        b2=findViewById(R.id.b2);
        b3=findViewById(R.id.b3);
        b4=findViewById(R.id.b4);



        b1.setOnClickListener(this);
        b2.setOnClickListener(this);
        b3.setOnClickListener(this);
        b4.setOnClickListener(this);
    }


    @Override
    public void onClick(View view) {
        a=Integer.parseInt(e1.getText().toString());
        b=Integer.parseInt(e2.getText().toString());
        switch(view.getId())
        {
            case R.id.b1:
                Toast.makeText(getApplicationContext(),"Addition is "+(a+b),Toast.LENGTH_LONG).show();
                break;
            case R.id.b2:
                Toast.makeText(getApplicationContext(),"Substraction is "+(a-b),Toast.LENGTH_LONG).show();
                break;
            case R.id.b3:
                Toast.makeText(getApplicationContext(),"Multiplication is "+(a*b),Toast.LENGTH_LONG).show();
                break;

            case R.id.b4:
                Toast.makeText(getApplicationContext(),"Division is "+(a/b),Toast.LENGTH_LONG).show();
                break;

default:Toast.makeText(getApplicationContext(),"Select correct Button",Toast.LENGTH_LONG).show();


        }

    }
}
