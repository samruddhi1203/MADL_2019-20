package khaire.pranoti.s.bmicalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
EditText e1,e2;
Button b1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        e1=findViewById(R.id.editText1);
        e2=findViewById(R.id.editText2);
        b1=findViewById(R.id.button1);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                double weight= Double.parseDouble(e1.getText().toString());
                double height= Double.parseDouble(e2.getText().toString());

                double bmi=weight/(height*height);
                if(bmi<18.5)
                {
                    Toast.makeText(getApplicationContext(), "underweight  " +bmi, Toast.LENGTH_LONG).show();
                }
                else if(bmi>=18.5 && bmi<24.9)
                {
                    Toast.makeText(getApplicationContext(),"healthy  " +bmi,Toast.LENGTH_LONG).show();

                }
                else if(bmi>=24.9 && bmi<30)
                {
                    Toast.makeText(getApplicationContext(),"overweight  " +bmi,Toast.LENGTH_LONG).show();

                }
                else if(bmi >=30)
                {
                    Toast.makeText(getApplicationContext(),"suffering from obesity  " +bmi,Toast.LENGTH_LONG).show();

                }

            }
        });
    }
}
