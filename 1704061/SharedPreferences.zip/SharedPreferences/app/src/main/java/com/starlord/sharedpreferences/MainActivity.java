package com.starlord.sharedpreferences;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button b1,b2,b3;
    EditText ed1,ed2;
    SharedPreferences sp;
    SharedPreferences.Editor ed;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sp=getSharedPreferences("RIT",MODE_PRIVATE);
        ed=sp.edit();

        Button b1=findViewById(R.id.button);
        Button b2=findViewById(R.id.button2);
        Button b3=findViewById(R.id.button3);
        final EditText ed1=findViewById(R.id.editText);
        final EditText ed2=findViewById(R.id.editText2);

        if(sp.contains("Userid"))
        {
            ed1.setText(sp.getString("Userid",null));
        }

        if(sp.contains("Password"))
        {
            ed2.setText(sp.getString("Password",null));
        }

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nm=ed1.getText().toString();
                String pass=ed2.getText().toString();
                ed.putString("Userid",nm);
                ed.putString("Password",pass);
                ed.commit();
                Toast.makeText(getApplicationContext(),"SAVED",Toast.LENGTH_LONG).show();
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s1=null,s2=null;
                if(sp.contains("Userid"))
                {
                    s1=(sp.getString("Userid",null));
                }

                if(sp.contains("Password"))
                {
                    s2=(sp.getString("Password",null));
                }
                ed1.setText(s1);
                ed2.setText(s2);
            }
        });

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ed1.setText("");
                ed2.setText("");
            }
        });
    }
}
