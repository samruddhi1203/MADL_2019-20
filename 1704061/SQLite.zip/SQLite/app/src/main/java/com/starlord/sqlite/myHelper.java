package com.starlord.sqlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class myHelper extends SQLiteOpenHelper {

    public myHelper(Context context){
        super(context,"RIT.db",null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table Student(Roll_no int,Name varchar(20))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists Student");
        onCreate(db);

    }

    public void insertrecord(int rn,String nm)
    {
        SQLiteDatabase db=getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put("Roll_no",rn);
        values.put("Name",nm);
        db.insert("Student",null,values);
    }

    public Cursor selectrecord()
    {
        SQLiteDatabase db=getWritableDatabase();
        Cursor c=db.rawQuery("select * from Student",null);
        return c;
    }

    public void deleterecord(int roll)
    {
        SQLiteDatabase db= getWritableDatabase();
        db.delete("Student","Roll_no=?",new String[]{String.valueOf(roll)});
    }

    public void updaterecord(int rn,String nm)
    {
        SQLiteDatabase db =getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put("Roll_no",rn);
        values.put("Name",nm);

        db.update("Student",values,"Roll_no=?",new String[]{String.valueOf(rn)});

    }


}
