package com.starlord.sqlite;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    myHelper mh;
    Button btn1,btn2,btn3,btn4;
    EditText editText1,editText2,editText3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mh = new myHelper(MainActivity.this);

        editText1=findViewById(R.id.ed1);
        editText2=findViewById(R.id.ed2);
        editText3=findViewById(R.id.ed3);
        btn1=findViewById(R.id.b1);
        btn2=findViewById(R.id.b2);
        btn3=findViewById(R.id.b3);
        btn4=findViewById(R.id.b4);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String roll=editText1.getText().toString();
                int r=Integer.parseInt(roll);
                String nm=editText2.getText().toString();
                mh.insertrecord(r,nm);
                Toast.makeText(getApplicationContext(),"Insert Sucessfully",Toast.LENGTH_LONG).show();
            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor c1= mh.selectrecord();
                StringBuilder sb=new StringBuilder();
                while (c1.moveToNext())
                {
                 sb.append(c1.getInt(0)+"AND"+c1.getString(1));
                }
              Toast.makeText(getApplicationContext(),sb.toString(),Toast.LENGTH_LONG).show();
            }
        });

        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String roll=editText3.getText().toString();
                int r=Integer.parseInt(roll);
                mh.deleterecord(r);
                Toast.makeText(getApplicationContext(),"Deleted Sucessfully",Toast.LENGTH_LONG).show();

            }
        });

        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String roll=editText3.getText().toString();
                int r=Integer.parseInt(roll);
                String nm=editText2.getText().toString();
                mh.updaterecord(r,nm);
                Toast.makeText(getApplicationContext(),"Update Sucessfully",Toast.LENGTH_LONG).show();
            }
        });
    }
}
