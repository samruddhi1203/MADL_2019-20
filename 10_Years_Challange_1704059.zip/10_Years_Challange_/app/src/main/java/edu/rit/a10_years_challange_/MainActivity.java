package edu.rit.a10_years_challange_;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText ed1,ed2;
    Button btn_reg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ed1=findViewById(R.id.username);
        ed2=findViewById(R.id.password);
        btn_reg=findViewById(R.id.register);





        btn_reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(MainActivity.this,Login.class);
                String user=ed1.getText().toString();
                String pass=ed2.getText().toString();

                i.putExtra("key1",user);
                i.putExtra("key2",pass);
                startActivity(i);
            }
        });

    }
}
