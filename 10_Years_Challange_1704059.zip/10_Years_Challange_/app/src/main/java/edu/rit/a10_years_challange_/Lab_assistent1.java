package edu.rit.a10_years_challange_;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

public class Lab_assistent1 extends AppCompatActivity {

    ImageButton click_here_;
    ImageView imageView1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab_assistent1);
        click_here_=findViewById(R.id.click_here_1);
        imageView1=findViewById(R.id.Lab_current);

        click_here_.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imageView1.setImageResource(R.drawable.lab_assistent_before);

            }
        });

    }
}
