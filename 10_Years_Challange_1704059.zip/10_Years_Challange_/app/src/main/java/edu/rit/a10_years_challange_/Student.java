package edu.rit.a10_years_challange_;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

public class Student extends AppCompatActivity {

    ImageButton click_here;
    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student);

        click_here=findViewById(R.id.click_here_);
        imageView=findViewById(R.id.nobitaa_current);

        click_here.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imageView.setImageResource(R.drawable.nobita_kid);

            }
        });


    }
}
