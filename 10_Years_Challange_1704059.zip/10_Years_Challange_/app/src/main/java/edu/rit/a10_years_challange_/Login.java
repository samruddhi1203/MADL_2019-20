package edu.rit.a10_years_challange_;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class Login extends AppCompatActivity {
    EditText edt1,edt2;
    Button btn_login;
    Spinner sp;
    ArrayAdapter arrayAdapter;
    String selected_person;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        edt1=findViewById(R.id.usr_nm);
        edt2=findViewById(R.id.password2);
        btn_login=findViewById(R.id.login);
        sp=findViewById(R.id.spinner);

        String person[]={"Faculty","Student","Lab_Assistent"};
        arrayAdapter=new ArrayAdapter(this,android.R.layout.simple_spinner_item,person);

        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        sp.setAdapter(arrayAdapter);

        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {
                 selected_person=((TextView)view).getText().toString();


            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });





        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i1=getIntent();
                String uname=i1.getStringExtra("key1");
                String pass1=i1.getStringExtra("key2");
                String uname1=edt1.getText().toString();
                String pass2=edt2.getText().toString();

                if(uname.equals(uname1) && pass1.equals(pass2))
                {
                   Toast.makeText(Login.this,"Login Succesfull",Toast.LENGTH_LONG).show();
                   if(selected_person=="Faculty")
                   {
                        Intent i9=new Intent(Login.this,Faculty.class);
                        startActivity(i9);
                    }
                   else if (selected_person=="Student")
                   {
                       Intent i3=new Intent(Login.this,Student.class);
                       startActivity(i3);
                   }
                   else if (selected_person=="Lab_Assistent")
                   {
                       Intent i4=new Intent(Login.this,Lab_assistent1.class);
                       startActivity(i4);
                   }
                }

                else
                {
                   Toast.makeText(Login.this,"PLease enter valid username or password",Toast.LENGTH_LONG).show();

                }

            }
        });

    }
}
