package edu.rit.a10_years_challange_;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

public class Faculty extends AppCompatActivity {


    ImageButton click_here_faculty;
    ImageView imageView2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_faculty);


        click_here_faculty=findViewById(R.id.click_here2);
        imageView2=findViewById(R.id.faculty_current);

        click_here_faculty.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imageView2.setImageResource(R.drawable.before);

            }
        });



    }
}
