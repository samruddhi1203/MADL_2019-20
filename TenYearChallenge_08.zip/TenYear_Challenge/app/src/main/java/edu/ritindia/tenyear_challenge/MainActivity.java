package edu.ritindia.tenyear_challenge;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText e1, e2;
    Button login;
   String list[]={"Shinchan","Doreomon","Oggy"};
   Spinner spinner;
   ArrayAdapter ad;
   String itemname;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        e1 = findViewById(R.id.etname);
        e2 = findViewById(R.id.etpassword);
        login = findViewById(R.id.login);
        spinner=findViewById(R.id.spinner);
        ArrayAdapter ad=new ArrayAdapter(this,android.R.layout.simple_spinner_item,list);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_item);
       spinner.setAdapter(ad);



                spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        itemname=((TextView)view).getText().toString();
                       //.Toast.makeText(getApplicationContext(),"logged into"+itemname,Toast.LENGTH_LONG).show();
                        login.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                if(TextUtils.isEmpty(e1.getText().toString()))
                                {
                                e1.setError("Username is required");
                                }
                                if(TextUtils.isEmpty(e2.getText().toString()))
                                {
                                    e2.setError("Password is required");
                                }
                                else{
                                if(itemname==list[0])
                                {
                                    Toast.makeText(getApplicationContext(),"logged into "+itemname,Toast.LENGTH_LONG).show();
                                    Intent i=new Intent(MainActivity.this,Shinchan.class);
                                    startActivity(i);
                                }
                                if(itemname==list[1])
                                {
                                    Toast.makeText(getApplicationContext(),"logged into"+itemname,Toast.LENGTH_LONG).show();
                                    Intent i1=new Intent(MainActivity.this,Doreomon.class);
                                    startActivity(i1);
                                }
                                if(itemname==list[2])
                                {
                                    Toast.makeText(getApplicationContext(),"logged into"+itemname,Toast.LENGTH_LONG).show();
                                    Intent i2=new Intent(MainActivity.this,Oggy.class);
                                    startActivity(i2);
                                }
                            }}
                        });

                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });
              //  Toast.makeText(getApplicationContext(), "Successfully Logged in into "+itemname, Toast.LENGTH_LONG).show();
            }



    }
