package edu.ritindia.tenyear_challenge;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

public class Shinchan1 extends AppCompatActivity {
 ImageButton ib1;
 ImageView iv1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shinchan1);
        setTitle("Shinchan:After Ten Year");
        ib1=findViewById(R.id.imageButton2);
        iv1=findViewById(R.id.imageView2);
        ib1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(Shinchan1.this,Shinchan.class);
                startActivity(i);
            }
        });
    }
}
