package edu.ritindia.tenyear_challenge;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

public class Doreomon extends AppCompatActivity {
    ImageView iv;
    ImageButton ib;
    Button b1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doreomon);
        setTitle("Doreomon:Before Ten years");
        iv=findViewById(R.id.ivdm1);
        ib=findViewById(R.id.ibdm1);
        b1=findViewById(R.id.back2);
        ib.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(getApplicationContext(),"Welcome ",Toast.LENGTH_LONG).show();
                Intent i2=new Intent(Doreomon.this,Doreomon1.class);
                startActivity(i2);
            }
        });
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(Doreomon.this,MainActivity.class);
                startActivity(i);
            }
        });
    }
}
