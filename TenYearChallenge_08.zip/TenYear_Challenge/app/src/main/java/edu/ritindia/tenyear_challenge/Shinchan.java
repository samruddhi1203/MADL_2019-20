package edu.ritindia.tenyear_challenge;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

public class Shinchan extends AppCompatActivity {
ImageView iv;
ImageButton ib;
Button b1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shinchan);
        setTitle("Shinchan:Before Ten years");
        iv=findViewById(R.id.imageView);
        ib=findViewById(R.id.imageButton);
        b1=findViewById(R.id.back);
        ib.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(getApplicationContext(),"Welcome ",Toast.LENGTH_LONG).show();
                Intent i1=new Intent(Shinchan.this,Shinchan1.class);
                startActivity(i1);
            }
        });
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(Shinchan.this,MainActivity.class);
                startActivity(i);
            }
        });
    }
}
