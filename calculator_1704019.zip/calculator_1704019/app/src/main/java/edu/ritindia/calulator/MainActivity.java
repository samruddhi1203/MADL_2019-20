package edu.ritindia.calulator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
EditText et1,et2;
Button b1,b2,b3,b4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et1 = findViewById(R.id.editText1);
        et2 = findViewById(R.id.editText2);
        b1 = findViewById(R.id.button1);
        b2 = findViewById(R.id.button2);
        b3 = findViewById(R.id.button3);
        b4 = findViewById(R.id.button4);
        b1.setOnClickListener(this);
        b2.setOnClickListener(this);
        b3.setOnClickListener(this);
        b4.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {
        String num1=et1.getText().toString();
        String num2=et2.getText().toString();
        int a=Integer.parseInt(num1);
        int b=Integer.parseInt(num2);
        if(v.getId()==R.id.button1)
        {
            Toast.makeText(getApplicationContext(), "addition is "+(a+b), Toast.LENGTH_SHORT).show();
        }
        if(v.getId()==R.id.button2) {
            Toast.makeText(getApplicationContext(), "substraction is " + (a-b), Toast.LENGTH_SHORT).show();
        }
        if(v.getId()==R.id.button3) {
            Toast.makeText(getApplicationContext(), "multipliaction is "+(a*b), Toast.LENGTH_SHORT).show();
        }
        if(v.getId()==R.id.button4) {
            Toast.makeText(getApplicationContext(), "division is "+(a/b), Toast.LENGTH_SHORT).show();
        }
    }
}
