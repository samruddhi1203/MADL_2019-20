package edu.rit.prajakta.cal2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText et1,et2,et4;
    Button btn;

    double wt,ht,re;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et1=findViewById(R.id.editText1);
        et2=findViewById(R.id.editText2);
        et4=findViewById(R.id.editText4);
        btn=findViewById(R.id.button);


        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                wt = Double.parseDouble(et1.getText().toString());
                ht = Double.parseDouble(et2.getText().toString());
                ht = ht/100;
                re= wt/(ht*ht);
             //  Toast.makeText(getApplicationContext(),"BMI : "+(re), Toast.LENGTH_LONG).show();

                et4.setText(String.valueOf(re));

            }
        });
    }
}
