package com.xyz.bmi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    EditText e1,e2;
    TextView t1;
    Button b1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        e1=findViewById(R.id.e1);
        e2=findViewById(R.id.e2);
        t1=findViewById(R.id.t1);
        b1=findViewById(R.id.b1);




        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                float h=Float.parseFloat(e1.getText().toString());
                float w=Float.parseFloat(e2.getText().toString());
                float c=(float)w/(h*h);
                if(c<=18.5) {
                    Toast.makeText(getApplicationContext(), "BMI is " + c + " UnderWeighted", Toast.LENGTH_LONG).show();
                }
                else if(c>24.9)
                {
                    Toast.makeText(getApplicationContext(), "BMI is " + c + " OverWeighted", Toast.LENGTH_LONG).show();
                }
                else
                {
                    Toast.makeText(getApplicationContext(), "BMI is " + c + " Good", Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}
