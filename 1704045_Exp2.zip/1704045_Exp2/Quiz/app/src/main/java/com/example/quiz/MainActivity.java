package com.example.quiz;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    TextView tv1, tv2, tv3;
    RadioButton r1, r2, r3, r4, r5, r6, r7, r8, r9, r0, r11, r12;
    Button bt;
    RadioGroup rg1, rg2, rg3;
    int res;
    int selectedId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        addListenerOnButton();
    }

    public void addListenerOnButton() {
        //tv1 = (TextView) findViewById(R.id.textView);
        //tv2 = (TextView) findViewById(R.id.textView2);
        //tv3 = (TextView) findViewById(R.id.textView3);

      //  rg1 = (RadioGroup) findViewById(R.id.radioGroup);
       // rg2 = (RadioGroup) findViewById(R.id.radioGroup2);
       // rg3 = (RadioGroup) findViewById(R.id.radioGroup3);

        //r1 = (RadioButton) findViewById(R.id.radioButton);
        //r2 = (RadioButton) findViewById(R.id.radioButton2);
        //r3 = (RadioButton) findViewById(R.id.radioButton3);
        r4 = (RadioButton) findViewById(R.id.radioButton4);

        //r5 = (RadioButton) findViewById(R.id.radioButton5);
        r6 = (RadioButton) findViewById(R.id.radioButton6);
        //r7 = (RadioButton) findViewById(R.id.radioButton7);
        //r8 = (RadioButton) findViewById(R.id.radioButton8);

        r9 = (RadioButton) findViewById(R.id.radioButton9);
        //r0 = (RadioButton) findViewById(R.id.radioButton10);
        //r11 = (RadioButton) findViewById(R.id.radioButton11);
        //r12 = (RadioButton) findViewById(R.id.radioButton12);

        //rg1.clearChecked();
        //rg2.clearChecked();
        //rg3.clearChecked();


        bt = (Button) findViewById(R.id.button);
        res = 0;

final int Q1=10;
        bt.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                //selectedId = radioGroup.getCheckedRadioButtonId();
                //radioButton = (RadioButton) findViewById(selectedId);

                if (r4.isChecked())
                    res = Q1 + res;
                else
                    res = res;

                if (r6.isChecked())
                    res = Q1 + res;

                else
                    res = res;

                if (r9.isChecked())
                    res = Q1 + res;

                else
                    res = res;



                Toast.makeText(MainActivity.this, "Result is " + res, Toast.LENGTH_LONG).show();
               res=0;
            }

        });
     }

}


























