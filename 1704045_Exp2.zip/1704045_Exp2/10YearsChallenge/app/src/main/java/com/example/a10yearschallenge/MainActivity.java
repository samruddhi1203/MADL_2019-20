package com.example.a10yearschallenge;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompatSideChannelService;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {


    Button login;
    EditText user,pass;
    ArrayAdapter dataAdapter;
    Spinner spinner;
    String selected_role;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        login=findViewById(R.id.button1);
        user=findViewById(R.id.editText);
        pass=findViewById(R.id.editText2);
        login.setOnClickListener(this);

       spinner=findViewById(R.id.spinner);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

            selected_role=((TextView)view).getText().toString();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                Toast.makeText(getApplicationContext(),"Select any Role.",Toast.LENGTH_SHORT).show();
            }
        });

        List<String>op=new ArrayList<String>();
        op.add("Student");
        op.add("Faculty");
        op.add("Lab Assistant");
        dataAdapter=new ArrayAdapter(this,android.R.layout.simple_spinner_item,op);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(dataAdapter);


    }
    @Override
    public void onClick(View v) {
        String u="PRACHI";
        String p="1704045";
        String f="DEF";
        String fp="456";
        String l="GHI";
        String lp="789";
      /*  String st="Student";
        String ft="Faculty";
        String lt="Lab Assistant";*/
        String ur=user.getText().toString();
        String ps=pass.getText().toString();
        if(v.getId()==login.getId())
        {
            if(selected_role=="Student")
            {
                if(ur.equals(u) && ps.equals(p) )
                {
                    Toast.makeText(getApplicationContext(),"Login Successful",Toast.LENGTH_SHORT).show();
                    Intent i=new Intent(getBaseContext(),Student_Page.class);
                    startActivity(i);
                }
                else
                {
                    Toast.makeText(getApplicationContext(),"Check the Credentials",Toast.LENGTH_SHORT).show();
                }

            }else if(selected_role=="Faculty")
            {
                if(ur.equals(f) && ps.equals(fp) )
                {
                    Toast.makeText(getApplicationContext(),"Login Successful",Toast.LENGTH_SHORT).show();
                    Intent i=new Intent(getBaseContext(),Faculty_page.class);
                    startActivity(i);
                }
                else
                {
                    Toast.makeText(getApplicationContext(),"Check the Credentials",Toast.LENGTH_SHORT).show();
                }
            }
            else if(selected_role=="Lab Assistant")
            {
                if(ur.equals(l) && ps.equals(lp))
                {
                    Toast.makeText(getApplicationContext(),"Login Successful",Toast.LENGTH_SHORT).show();
                    Intent i=new Intent(getBaseContext(),Lab_page.class);
                    startActivity(i);
                }
                else
                {
                    Toast.makeText(getApplicationContext(),"Check the Credentials",Toast.LENGTH_SHORT).show();
                }
            }

            else
            {
                Toast.makeText(getApplicationContext(),"Check the Credentials",Toast.LENGTH_SHORT).show();
            }


        }
    }




}
