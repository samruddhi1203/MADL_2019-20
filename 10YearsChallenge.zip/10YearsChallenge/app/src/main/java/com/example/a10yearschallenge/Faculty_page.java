package com.example.a10yearschallenge;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

public class Faculty_page extends AppCompatActivity {

    ImageView i;
    ImageButton b;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_faculty_page);
        i=findViewById(R.id.imageView2);
        b=findViewById(R.id.imageButton2);

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                i.setImageResource(R.drawable.afaculty);
                Toast.makeText(getApplicationContext(),"Photo of Faculty after 10 years",Toast.LENGTH_LONG).show();

            }
        });
    }
}
